"""Sequential real-TPU jobs for the corrected author-supplied timing protocol."""
import argparse,base64,gzip,hashlib,json,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--core-only',action='store_true')
 parser.add_argument('--output-dir',default='/content/atomic-corrected-original-results')
 a=parser.parse_args();out=Path(a.output_dir);out.mkdir(exist_ok=True)
 jobs=[]
 for profile in ('production','strict'):
  jobs.append((f'kernel-{profile}-h6-l2048','corrected_original_kernel.py',['--profile',profile],3600))
 for profile in ('production','strict'):
  jobs.append((f'e2e-{profile}','corrected_original_e2e.py',['--profile',profile],10800))
 if not a.core_only:
  for profile in ('production','strict'):
   for heads in (2,4,6):
    for length in (2048,4096):
     if (heads,length)==(6,2048):continue
     jobs.append((f'kernel-{profile}-h{heads}-l{length}','corrected_original_kernel.py',
      ['--profile',profile,'--shape',f'4,{length},{heads},128'],3600))
 state=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),cases=[],planned_cases=len(jobs),
  protocol='Corrected supplied original scripts; original medians/counts/order per round, three seeds, three repeated rounds; no publication')
 def save():(out/'suite-status.json').write_text(json.dumps(state,indent=2))
 save()
 for name,script,flags,limit in jobs:
  dest=out/(name+'.json');log=out/(name+'.log')
  row=dict(name=name,command=[sys.executable,'-u',str(HERE/script),*flags,'--output',str(dest)],started=time.time())
  state['active']=name;save();print('START',name,flush=True)
  with log.open('w') as stream:
   process=subprocess.Popen(row['command'],stdout=stream,stderr=subprocess.STDOUT)
   last=''
   while process.poll() is None:
    elapsed=time.time()-row['started']
    if elapsed>limit:
     process.terminate();process.wait();row['status']='timeout';break
    current=log.read_text(errors='replace')[-1000:]
    if current!=last:print('PROGRESS',name,round(elapsed),current,flush=True);last=current
    time.sleep(10)
   row['exit_code']=process.returncode
  row['elapsed_seconds']=time.time()-row['started']
  if dest.exists():
   raw=dest.read_bytes();data=json.loads(raw)
   row.setdefault('status',data['status']);row['speedup']=data.get('speedup');row['detail']=data.get('detail')
   row['result_sha256']=hashlib.sha256(raw).hexdigest()
   # Recovery copy in notebook output, in addition to raw JSON/log and final ZIP.
   print('RESULT_JSON_GZIP_BASE64',name,base64.b64encode(gzip.compress(raw,mtime=0)).decode(),flush=True)
  else:row.setdefault('status','process_failed_without_json')
  row['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
  state['cases'].append(row);save();print('FINISH',json.dumps(row),flush=True)
 state.update(status='completed',active=None,finished_utc=datetime.now(timezone.utc).isoformat());save()
 print('SUITE_COMPLETE',len(state['cases']),'passed',sum(c['status']=='passed' for c in state['cases']),flush=True)

if __name__=='__main__':main()
