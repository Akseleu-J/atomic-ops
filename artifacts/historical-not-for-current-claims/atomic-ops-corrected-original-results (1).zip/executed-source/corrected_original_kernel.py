"""Original kernel timing method with corrected OLD mathematics and mandatory gates."""
import argparse,json,statistics,traceback
import corrected_original_common as c

def run(a):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 shape=tuple(map(int,a.shape.split(',')));assert len(shape)==4 and shape[1]%128==0 and shape[-1]==128
 p,cfg=c.paths(profile=a.profile)
 report=dict(status='running',kind='corrected_original_kernel',shape=list(shape),profile=a.profile,config=cfg,
  environment=c.environment(),tolerance_rel_l2=c.TOL,objective='sum(o**2)+sum(h_final**2)',
  measured_returns='jax.grad with q/k/v/w/b/g; h0 captured, not differentiated in timer',
  untimed_validation='o, h_final, loss and all seven input gradients',
  precision_note='Explicit highest baseline matmuls; production Pallas retains bf16x3 and damping=1e-3; strict has highest and zero damping',
  protocol='Original order OLD then NEW; one warmup; OLD3/NEW5 synchronized samples per round; median, population SD',seeds=[])
 small,_=c.inputs(12345,(1,128,1,128));oracle=c.jax.jit(c.jax.value_and_grad(c.loss_for(p['SERIAL']),argnums=tuple(range(7))))(*small)
 oracle_out=c.jax.jit(p['SERIAL'])(*small)
 report['short_serial_gates']={}
 for name in ('OLD','NEW'):
  gate=dict(forward=c.check(c.jax.jit(p[name])(*small),oracle_out),
   gradient=c.check(c.jax.jit(c.jax.value_and_grad(c.loss_for(p[name]),argnums=tuple(range(7))))(*small),oracle))
  report['short_serial_gates'][name]=gate
  if not all(v['passed'] for v in gate.values()):report['status']='serial_gate_failed';return report
 fwds={};grad7={}
 for seed in a.seeds:
  args,digest=c.inputs(seed,shape);exes={};compile_s={}
  for name in ('OLD','NEW'):
   if name not in fwds:
    fwds[name],_=c.compile_fn(p[name],args)
    grad7[name],_=c.compile_fn(c.jax.value_and_grad(c.loss_for(p[name]),argnums=tuple(range(7))),args)
   def historical_loss(*xs,_fn=p[name],_h0=args[-1]):return c.loss_for(_fn)(*xs,_h0)
   exes[name],compile_s[name]=c.compile_fn(c.jax.grad(historical_loss,argnums=tuple(range(6))),args[:-1])
  checks=dict(forward=c.check(fwds['NEW'](*args),fwds['OLD'](*args)),
   gradient7=c.check(grad7['NEW'](*args),grad7['OLD'](*args)),
   timed_gradient6=c.check(exes['NEW'](*args[:-1]),exes['OLD'](*args[:-1])))
  row=dict(seed=seed,input_sha256=digest,checks=checks,compile_seconds=compile_s,
   passed=all(x['passed'] for x in checks.values()),rounds=[])
  if row['passed']:
   for rnd in range(a.rounds):
    timing={name:c.timed(exes[name],args[:-1],3 if name=='OLD' else 5,1) for name in ('OLD','NEW')}
    row['rounds'].append(dict(round=rnd,timing=timing,speedup=timing['OLD']['median_ms']/timing['NEW']['median_ms']))
   row['speedup']=statistics.median(r['speedup'] for r in row['rounds'])
  report['seeds'].append(row)
  print('CORRECTED_KERNEL_SEED',seed,row['passed'],row.get('speedup'),flush=True)
  c.save(report,a.output)
 report['status']='passed' if all(s['passed'] for s in report['seeds']) else 'gate_failed'
 if report['status']=='passed':
  vals=[s['speedup'] for s in report['seeds']]
  report['speedup']=dict(per_seed=vals,mean=statistics.mean(vals),sample_sd=statistics.stdev(vals) if len(vals)>1 else 0.,
   historical_single_trial=report['seeds'][0]['rounds'][0]['speedup'],summary_method='median of round ratios per seed; then mean and sample SD across seeds')
 return report

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--profile',choices=('strict','production'),default='production');p.add_argument('--seeds',nargs='+',type=int,default=[0,1,2])
 p.add_argument('--shape',default='4,2048,6,128')
 p.add_argument('--rounds',type=int,default=3);p.add_argument('--output',default='corrected-original-kernel.json')
 a=p.parse_args();assert a.rounds>=1 and len(set(a.seeds))==len(a.seeds)
 try:r=run(a)
 except Exception as e:r=dict(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc(),environment=c.environment())
 c.save(r,a.output);print('FINAL_CORRECTED_KERNEL',r['status'],r.get('speedup'),flush=True)
 return 0 if r['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
