"""Same-model same-Adam-update benchmark. This is a new protocol, not a recovered old log."""
import argparse, hashlib, json, math, os, statistics, sys, time, traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from honest_gdn2 import jax,jnp,np,PREC,TOL,make_paths,tree_comparison,compile_fn,environment

def init(seed,width=384,ff=768,layers=5,vocab=32768,heads=6,head_dim=128):
    rng=np.random.default_rng(seed)
    def matrix(i,o):return jax.device_put((rng.normal(size=(i,o))*.5/math.sqrt(i)).astype(np.float32))
    blocks=[]
    for _ in range(layers):
        blocks.append(dict(norm1=jnp.ones(width),norm2=jnp.ones(width),
            proj=tuple(matrix(width,heads*head_dim) for _ in range(6)),out=matrix(heads*head_dim,width),
            up=matrix(width,ff),gate=matrix(width,ff),down=matrix(ff,width)))
    return dict(embedding=matrix(vocab,width),blocks=tuple(blocks),norm=jnp.ones(width))

def lm_loss(kernel,params,tokens,targets):
    x=params['embedding'][tokens]; B,L,W=x.shape;H=6;D=128
    def norm(x,gain):return x*jax.lax.rsqrt(jnp.mean(x*x,-1,keepdims=True)+1e-6)*gain
    def mm(x,w):return jnp.matmul(x,w,precision=PREC)
    def layer(x,p):
        z=norm(x,p['norm1']);qs=[mm(z,pj).reshape(B,L,H,D) for pj in p['proj']]
        q,k,v,w,b,g=qs
        q=q*jax.lax.rsqrt(jnp.sum(q*q,-1,keepdims=True)+1e-6)
        k=k*jax.lax.rsqrt(jnp.sum(k*k,-1,keepdims=True)+1e-6)
        b=jax.nn.sigmoid(b);g=-jax.nn.softplus(g-3.)
        h0=jnp.full((B,H,D,D),.01,jnp.float32)
        o,_=kernel(q,k,v,w,b,g,h0)
        x=x+mm(o.reshape(B,L,H*D),p['out'])
        z=norm(x,p['norm2'])
        return x+mm(jax.nn.silu(mm(z,p['gate']))*mm(z,p['up']),p['down'])
    for block in params['blocks']:x=jax.checkpoint(layer)(x,block)
    x=norm(x,params['norm']).reshape(-1,W)
    y=targets.reshape(-1);N=x.shape[0];C=128
    def ce(_,xy):
        xx,yy=xy;logits=mm(xx,params['embedding'].T)
        val=jax.nn.logsumexp(logits,-1)-jnp.take_along_axis(logits,yy[:,None],axis=-1)[:,0]
        return None,jnp.sum(val)
    _,totals=jax.lax.scan(jax.checkpoint(ce),None,(x.reshape(N//C,C,W),y.reshape(N//C,C)))
    return jnp.sum(totals)/N

def objective(kernel,micro):
    def loss(params,tokens,targets):
        B,L=tokens.shape
        def one(_,xy):return None,lm_loss(kernel,params,*xy)
        _,vals=jax.lax.scan(jax.checkpoint(one),None,
            (tokens.reshape(B//micro,micro,L),targets.reshape(B//micro,micro,L)))
        return jnp.mean(vals)
    return loss

def update_for(loss):
    def update(params,m,v,step,tokens,targets):
        val,grads=jax.value_and_grad(loss)(params,tokens,targets)
        step=step+1
        m=jax.tree.map(lambda m,g:.9*m+.1*g,m,grads)
        v=jax.tree.map(lambda v,g:.999*v+.001*g*g,v,grads)
        new=jax.tree.map(lambda p,mm,vv:p-1e-4*(mm/(1-.9**step))/(jnp.sqrt(vv/(1-.999**step))+1e-8),params,m,v)
        return val,new,m,v,step
    return update

def run(a):
    paths,cfg=make_paths(128,a.profile)
    param=init(0);zeros=jax.tree.map(jnp.zeros_like,param)
    rng=np.random.default_rng(0)
    data=jax.device_put(rng.integers(0,32768,(a.batch,a.length+1),dtype=np.int32))
    args=(param,zeros,zeros,jnp.array(0,jnp.int32),data[:,:-1],data[:,1:])
    report=dict(kind='end_to_end',protocol='New fixed-state replay of complete LM forward+CE+backward+Adam update',
        layers=5,width=384,ffn=768,vocab=32768,heads=6,head_dim=128,tied_embedding=True,
        params=sum(x.size for x in jax.tree.leaves(param)),batch=a.batch,length=a.length,
        microbatch=a.microbatch,profile=a.profile,config=cfg,environment=environment(),
        tolerance_rel_l2=TOL,repeats=a.repeats,warmup=a.warmup,compile_excluded=True,
        data_loading_excluded=True,ce_chunk_tokens=128,seeds=[],historical_200_17_reproduction=False)
    exes={};gradf={};compile_s={}
    for name in ('associative_scan','jax_wy','pallas'):
        loss=objective(paths[name],a.microbatch)
        print('E2E_COMPILE',name,flush=True)
        gradf[name],_=compile_fn(jax.value_and_grad(loss),(param,args[-2],args[-1]))
        exes[name],compile_s[name]=compile_fn(update_for(loss),args)
    report['compile_seconds']=compile_s
    for seed in a.seeds:
        param=init(seed);zeros=jax.tree.map(jnp.zeros_like,param)
        rng=np.random.default_rng(seed);host=rng.integers(0,32768,(a.batch,a.length+1),dtype=np.int32)
        data=jax.device_put(host);args=(param,zeros,zeros,jnp.array(0,jnp.int32),data[:,:-1],data[:,1:])
        oracle=gradf['associative_scan'](param,args[-2],args[-1]);jax.block_until_ready(oracle)
        names=['loss']+[str(i) for i in range(len(jax.tree.leaves(param)))]
        checks={name:tree_comparison(gradf[name](param,args[-2],args[-1]),oracle,names) for name in ('jax_wy','pallas')}
        # Compare the entire update too, including moments, not just scalar loss.
        ref=exes['associative_scan'](*args)
        update_names=[str(i) for i in range(len(jax.tree.leaves(ref)))]
        update_checks={name:tree_comparison(exes[name](*args),ref,update_names) for name in ('jax_wy','pallas')}
        row=dict(seed=seed,input_sha256=hashlib.sha256(host.tobytes()).hexdigest(),checks=checks,update_checks=update_checks)
        row['passed']=all(x['passed'] for x in (*checks.values(),*update_checks.values()))
        if row['passed']:
            from honest_gdn2 import timings
            row['timing']=timings(exes,args,a.repeats,a.warmup,seed)
            samples=row['timing']['samples'];row['speedups']={name:samples[name]['median_ms']/samples['pallas']['median_ms']
                for name in ('associative_scan','jax_wy')}
            row['tokens_per_second']={name:a.batch*a.length/v['median_ms']*1000 for name,v in samples.items()}
        report['seeds'].append(row)
        print('E2E_SEED',seed,'passed',row['passed'],'ratios',row.get('speedups'),flush=True)
    report['status']='passed' if all(x['passed'] for x in report['seeds']) else 'gate_failed'
    if report['status']=='passed':report['speedups']={name:dict(mean=statistics.mean(x['speedups'][name] for x in report['seeds']),
        per_seed=[x['speedups'][name] for x in report['seeds']]) for name in ('associative_scan','jax_wy')}
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--batch',type=int,default=8);p.add_argument('--length',type=int,default=2048)
    p.add_argument('--microbatch',type=int,default=2);p.add_argument('--profile',choices=('strict','production'),default='strict')
    p.add_argument('--repeats',type=int,default=10);p.add_argument('--warmup',type=int,default=3)
    p.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);p.add_argument('--output',default='honest-e2e.json')
    a=p.parse_args();assert a.batch%a.microbatch==0 and a.length%128==0
    jax.config.update('jax_default_matmul_precision','highest')
    assert jax.default_backend()=='tpu' and jax.local_device_count()==1
    try:report=run(a)
    except Exception as e:report=dict(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc(),environment=environment())
    report['benchmark_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report['kernel_benchmark_sha256']=hashlib.sha256(Path(__file__).with_name('honest_gdn2.py').read_bytes()).hexdigest()
    Path(a.output).write_text(json.dumps(report,indent=2,allow_nan=False))
    print('FINAL_E2E',report['status'],report.get('speedups'),flush=True)
    return 0 if report['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
