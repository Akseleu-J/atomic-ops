"""Sequential fresh-process suite; saves failures and every raw timing, no publication."""
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('ATOMIC_BENCH_RESULTS','/content/atomic-honest-results'))
OUT.mkdir(parents=True,exist_ok=True)
jobs=[]
for profile in ('strict','production'):
    for heads in (2,4,6):
        for length in (2048,4096):
            name=f'kernel-{profile}-h{heads}-l{length}'
            jobs.append((name,[str(HERE/'honest_gdn2.py'),'--shape',f'4,{length},{heads},128','--profile',profile],1800))
for profile in ('strict','production'):
    jobs.append((f'e2e-{profile}',[str(HERE/'honest_e2e.py'),'--profile',profile],3600))
state=dict(started_utc=datetime.now(timezone.utc).isoformat(),status='running',cases=[])
def save():
    (OUT/'suite-status.json').write_text(json.dumps(state,indent=2))
save()
for name,args,limit in jobs:
    dest=OUT/(name+'.json');log=OUT/(name+'.log')
    begin=time.time();row=dict(name=name,command=[sys.executable,*args,'--output',str(dest)],started=begin)
    state['active']=name;save();print('START',name,flush=True)
    try:
        with log.open('w') as output:
            result=subprocess.run(row['command'],stdout=output,stderr=subprocess.STDOUT,timeout=limit)
        row['exit_code']=result.returncode
        if dest.exists():
            data=json.loads(dest.read_text());row['status']=data['status'];row['speedups']=data.get('speedups')
            row['result_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
            row['detail']=data.get('detail')
        else:row['status']='process_failed_without_json'
    except subprocess.TimeoutExpired:row['status']='timeout'
    except Exception as error:row.update(status='runner_error',error=type(error).__name__,detail=str(error))
    row['elapsed_seconds']=time.time()-begin
    row['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest() if log.exists() else None
    state['cases'].append(row);save();print('FINISH',name,row['status'],row.get('speedups'),flush=True)
state.update(status='completed',active=None,finished_utc=datetime.now(timezone.utc).isoformat())
save()
