"""Compare Pallas and JAX_REF at IDENTICAL damping; no timing or speedup claims."""
import argparse,dataclasses,json,traceback
import corrected_original_common as c
from corrected_original_e2e import initialize,make_functions
from corrected_original_lm import LMConfig
from atomic_ops.reference import gdn2_chunked_wy_reference

def named(got,ref):
 r=c.check(got,ref)
 paths=[c.jax.tree_util.keystr(p) for p,_ in c.jax.tree_util.tree_flatten_with_path(ref)[0]]
 for path,t in zip(paths,r['tensors']):t['path']=path
 r['max_rel_l2']=max(t['rel_l2'] for t in r['tensors'])
 r['failed_paths']=[t['path'] for t in r['tensors'] if not t['finite'] or t['rel_l2']>c.TOL]
 return r

def run(a):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 cfg=LMConfig();eps=a.wy_eps;scale=1/cfg.d_head**.5
 kc=c.make_cfg(bt=128,bc=64,score_bs=128,bs2=64,mb=8,diag='btl',wy_eps=eps,
              dot_mode='highest',solve_dot_mode='bf16x3',b3_dot_mode='bf16x3',interpret=False)
 kernel=c.make_blr_trainable(kc,scale)
 def pallas(q,k,v,w,b,g,h0):
  sw=lambda x:c.jnp.swapaxes(x,1,2)
  o,h=kernel(*(sw(x) for x in (q,k,v,w,b,g)),h0);return sw(o),h
 def reference(q,k,v,w,b,g,h0):
  return gdn2_chunked_wy_reference(q,k,v,g,b,w,scale,128,h0,wy_eps=eps)
 functions={n:make_functions(cfg,f) for n,f in [('PALLAS',pallas),('JAX_REF',reference)]}
 report=dict(status='running',environment=c.environment(),kernel_config=dataclasses.asdict(kc),
             config=dataclasses.asdict(cfg),batch=8,length=2048,matched_wy_eps=eps,
             reference='atomic_ops.reference.gdn2_chunked_wy_reference',tolerance_rel_l2=c.TOL,
             purpose='Implementation agreement at identical damping. No speed measurements.',
             diagnostic_source_sha256=c.hashlib.sha256(c.Path(__file__).read_bytes()).hexdigest(),seeds=[])
 exes={}
 for seed in (0,1,2):
  tokens=c.jnp.asarray(c.np.random.default_rng(seed).integers(0,256,(8,2048)),c.jnp.int32)
  params=initialize(cfg,seed,tokens)
  values={}
  for name,(loss,step,tx) in functions.items():
   state=tx.init(params)
   if name not in exes:
    print('COMPILE',name,eps,flush=True)
    gf,_=c.compile_fn(c.jax.value_and_grad(loss),(params,tokens))
    sf,_=c.compile_fn(step,(params,state,tokens));exes[name]=(gf,sf)
   gf,sf=exes[name]
   grads=gf(params,tokens);result=sf(params,state,tokens)
   c.jax.block_until_ready((grads,result));values[name]=(grads,result)
  (pg,ps),(rg,rs)=values['PALLAS'],values['JAX_REF']
  checks={'loss_and_gradients':named(pg,rg),'full_step':named(ps,rs),
          'parameter_updates':named(c.jax.tree.map(lambda x,p:x-p,ps[0],params),c.jax.tree.map(lambda x,p:x-p,rs[0],params))}
  # Extra metrics diagnose failures without replacing or relaxing the fixed gate.
  paths_params=c.jax.tree_util.tree_flatten_with_path(params)[0]
  gradients_p=c.jax.tree.leaves(pg[1]);gradients_r=c.jax.tree.leaves(rg[1])
  params_p=c.jax.tree.leaves(ps[0]);params_r=c.jax.tree.leaves(rs[0])
  details=[]
  for i,t in enumerate(checks['full_step']['tensors'][:len(paths_params)]):
   if t['rel_l2']<=c.TOL:continue
   gp,gr=map(c.np.asarray,(gradients_p[i],gradients_r[i]))
   dp,dr=map(c.np.asarray,(params_p[i],params_r[i]))
   index=c.np.unravel_index(c.np.argmax(c.np.abs(dp-dr)),dp.shape)
   details.append(dict(path=c.jax.tree_util.keystr(paths_params[i][0]),index=list(map(int,index)),
     gradient_pallas=float(gp[index]),gradient_reference=float(gr[index]),
     parameter_pallas=float(dp[index]),parameter_reference=float(dr[index]),
     gradient_sign_flips=int(c.np.count_nonzero(c.np.signbit(gp)!=c.np.signbit(gr))),
     reference_gradient_norm=float(c.np.linalg.norm(gr)),
     initially_zero=bool(c.np.all(c.np.asarray(paths_params[i][1])==0))))
  row=dict(seed=seed,checks=checks,failed_parameters=details,
           passed=all(v['passed'] for v in checks.values()))
  report['seeds'].append(row);c.save(report,a.output)
  print('MATCHED_DAMPING_SEED',eps,seed,{k:(v['passed'],v['max_rel_l2']) for k,v in checks.items()},flush=True)
 report['status']='passed' if all(r['passed'] for r in report['seeds']) else 'gate_failed'
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--wy-eps',type=float,choices=(0.,.001),required=True);p.add_argument('--output',required=True);a=p.parse_args()
 try:r=run(a)
 except Exception as e:r=dict(status='error',detail=str(e),traceback=traceback.format_exc())
 c.save(r,a.output);print('FINAL_MATCHED_DAMPING',r['status'],flush=True)
