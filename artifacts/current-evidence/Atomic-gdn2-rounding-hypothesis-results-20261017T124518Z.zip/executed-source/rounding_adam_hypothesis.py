"""Controlled CPU experiment: scan/WY rounding vs independent Decimal oracle and AdamW."""
import argparse,hashlib,importlib.metadata,json,math,os,platform,sys,time
from decimal import Decimal,localcontext
from pathlib import Path
os.environ['JAX_PLATFORMS']='cpu'
import jax
import jax.numpy as jnp
import numpy as np
import optax
jax.config.update('jax_enable_x64',True)
jax.config.update('jax_default_matmul_precision','highest')
import hypothesis_old as old
import hypothesis_wy32 as wy32
import hypothesis_wy64 as wy64

def exact(x):return Decimal.from_float(float(x))
def decimal_run(xs,direction,theta=Decimal(0),precision=80):
 """Independent literal recurrence plus forward tangent; no scan/WY implementation reuse."""
 with localcontext() as ctx:
  ctx.prec=precision
  q,k,v,w,b,g,h0=[np.asarray(x) for x in xs];D=q.shape[-1];L=q.shape[1]
  state=[[exact(h0[0,0,i,j]) for j in range(D)] for i in range(D)]
  tangent=[[Decimal(0) for j in range(D)] for i in range(D)]
  outputs=[];derivatives=[]
  for t in range(L):
   qq,kk,vv,ww,bb,gg=[[exact(x[0,t,0,i]) for i in range(D)] for x in (q,k,v,w,b,g)]
   dr=[exact(direction[0,t,0,i]) for i in range(D)]
   alpha=[x.exp() for x in gg]
   hs=[[alpha[i]*state[i][j] for j in range(D)] for i in range(D)]
   ds=[[alpha[i]*tangent[i][j] for j in range(D)] for i in range(D)]
   nv=[ww[j]*(vv[j]+theta*dr[j])-sum((bb[i]*kk[i]*hs[i][j] for i in range(D)),Decimal(0)) for j in range(D)]
   nd=[ww[j]*dr[j]-sum((bb[i]*kk[i]*ds[i][j] for i in range(D)),Decimal(0)) for j in range(D)]
   state=[[hs[i][j]+kk[i]*nv[j] for j in range(D)] for i in range(D)]
   tangent=[[ds[i][j]+kk[i]*nd[j] for j in range(D)] for i in range(D)]
   outputs.extend(Decimal('0.5')*sum((qq[i]*state[i][j] for i in range(D)),Decimal(0)) for j in range(D))
   derivatives.extend(Decimal('0.5')*sum((qq[i]*tangent[i][j] for i in range(D)),Decimal(0)) for j in range(D))
  return outputs+[x for row in state for x in row],derivatives+[x for row in tangent for x in row]

def decimal_objective(y,dy,coeff,mode,precision):
 with localcontext() as ctx:
  ctx.prec=precision
  if mode=='natural':
   value=sum((x*x/2 for x in y),Decimal(0));terms=[a*b for a,b in zip(y,dy)]
  else:
   cs=[exact(x) for x in coeff];value=sum((a*b for a,b in zip(cs,y)),Decimal(0));terms=[a*b for a,b in zip(cs,dy)]
  grad=sum(terms,Decimal(0));magnitude=sum(map(abs,terms),Decimal(0))
  return value,grad,magnitude

def serial(q,k,v,w,b,g,h0):
 def step(h,inputs):
  qt,kt,vt,wt,bt,gt=inputs
  h=h*jnp.exp(gt)[..., :,None]
  erase=jnp.einsum('bhd,bhdv->bhv',bt*kt,h,precision=jax.lax.Precision.HIGHEST)
  h=h+jnp.einsum('bhd,bhv->bhdv',kt,wt*vt-erase,precision=jax.lax.Precision.HIGHEST)
  o=.5*jnp.einsum('bhd,bhdv->bhv',qt,h,precision=jax.lax.Precision.HIGHEST)
  return h,o
 hf,o=jax.lax.scan(step,h0,tuple(jnp.moveaxis(x,1,0) for x in (q,k,v,w,b,g)))
 return jnp.moveaxis(o,0,1),hf

def inputs(seed,L,D):
 rng=np.random.default_rng(seed);shape=(1,L,1,D)
 q=rng.normal(size=shape).astype(np.float32);k=rng.normal(size=shape).astype(np.float32)
 q/=np.linalg.norm(q,axis=-1,keepdims=True);k/=np.linalg.norm(k,axis=-1,keepdims=True)
 v=(rng.normal(size=shape)*.2).astype(np.float32)
 w=rng.uniform(.2,.8,shape).astype(np.float32);b=rng.uniform(.2,.8,shape).astype(np.float32)
 g=-rng.uniform(.01,.04,shape).astype(np.float32)
 h=(rng.normal(size=(1,1,D,D))*.1).astype(np.float32)
 direction=(rng.normal(size=shape)*.2).astype(np.float32)
 return (q,k,v,w,b,g,h),direction,rng

def main(a):
 assert jax.default_backend()=='cpu' and jax.config.jax_enable_x64
 assert a.length%128==0
 report={'status':'running','scope':'Controlled reduced CPU recurrence, not the actual full-LM exact-gradient oracle',
  'environment':{'backend':jax.default_backend(),'jax':jax.__version__,'numpy':np.__version__,'optax':importlib.metadata.version('optax'),'x64':True,
    'python':sys.version,'platform':platform.platform(),'devices':[str(d) for d in jax.devices()],
    'default_matmul_precision':str(jax.config.jax_default_matmul_precision)},
  'shape':[1,a.length,1,a.dim],'dtype_of_stored_inputs':'float32, promoted without changing their values',
  'seeds_predeclared':a.seeds,'decimal_precision':a.precision,'cases':[]}
 functions={}
 for dtype_name,dtype in [('fp32',jnp.float32),('fp64',jnp.float64)]:
  for name in ('SERIAL','OLD','WY'):
   fn=serial if name=='SERIAL' else old.old_factory(.5) if name=='OLD' else (wy32 if dtype_name=='fp32' else wy64).gdn2_chunked_wy_reference
   for mode in ('natural','cancellation_stress'):
    def objective(theta,xs,direction,coeff,_name=name,_fn=fn,_mode=mode):
     q,k,v,w,b,g,h=xs;vv=v+theta*direction
     o,hf=_fn(q,k,vv,g,b,w,.5,128,h,wy_eps=0.) if _name=='WY' else _fn(q,k,vv,w,b,g,h)
     y=jnp.concatenate([o.reshape(-1),hf.reshape(-1)])
     return .5*jnp.sum(y*y) if _mode=='natural' else jnp.sum(y*coeff)
    functions[(dtype_name,name,mode)]=jax.jit(jax.value_and_grad(objective))
 for seed in a.seeds:
  print('START_SEED',seed,'Decimal precision',a.precision,'and',a.precision+30,flush=True)
  print('START_SEED',seed,flush=True)
  xs,dr,rng=inputs(seed,a.length,a.dim)
  y,dy=decimal_run(xs,dr,precision=a.precision)
  # Deliberate stress objective: choose a coefficient to cancel the high-precision
  # tangent sum, THEN round/store that coefficient in fp32. No algorithm-dependent search.
  coeff=rng.normal(0,.2,len(y)).astype(np.float32);pivot=max(range(len(dy)),key=lambda i:abs(dy[i]))
  with localcontext() as ctx:
   ctx.prec=a.precision
   other=sum((exact(coeff[i])*dy[i] for i in range(len(dy)) if i!=pivot),Decimal(0))
   coeff[pivot]=np.float32(float(-other/dy[pivot]))
  assert all(np.isfinite(x).all() for x in xs) and np.isfinite(coeff).all()
  digest=hashlib.sha256(b''.join(x.tobytes() for x in (*xs,dr,coeff))).hexdigest()
  np.savez_compressed(a.output.parent/f'inputs-seed{seed}.npz',**dict(zip(('q','k','v','w','b','g','h0'),xs)),direction=dr,coeff=coeff)
  yhi,dyhi=decimal_run(xs,dr,precision=a.precision+30)
  for mode in ('natural','cancellation_stress'):
   value,grad,terms=decimal_objective(y,dy,coeff,mode,a.precision)
   vh,gh,th=decimal_objective(yhi,dyhi,coeff,mode,a.precision+30)
   with localcontext() as ctx:
    ctx.prec=a.precision
    h=Decimal('1e-20')
    yp,dyp=decimal_run(xs,dr,theta=h,precision=a.precision)
    ym,dym=decimal_run(xs,dr,theta=-h,precision=a.precision)
    vp=decimal_objective(yp,dyp,coeff,mode,a.precision)[0]
    vm=decimal_objective(ym,dym,coeff,mode,a.precision)[0]
    fd=(vp-vm)/(2*h)
    assert abs(fd-grad)<Decimal('1e-30'),'Independent tangent/finite-difference disagreement'
    assert abs(gh-grad)<Decimal('1e-30'),'Decimal oracle not precision-stable'
    condition=float(terms/abs(grad)) if grad else None
   row={'seed':seed,'mode':mode,'input_sha256':digest,'oracle_gradient_decimal':str(gh),
        'oracle_value_decimal':str(vh),'oracle_precision_stability_abs':float(abs(gh-grad)),
        'central_finite_difference_abs_error':float(abs(fd-grad)),
        'derivative_sum_abs_terms':float(terms),'derivative_cancellation_ratio':condition,
        'stress_construction':'Predeclared pivot=max(abs(Decimal tangent)); only one fp32 coefficient adjusted; same stored inputs/objective for all algorithms',
        'oracle_first_Adam_adaptive_update_lr1e-3':-1e-3*float(gh)/(abs(float(gh))+1e-8),
        'results':[]}
   for dtype_name,dtype in [('fp32',jnp.float32),('fp64',jnp.float64)]:
    values=tuple(jnp.asarray(x,dtype) for x in xs);dd=jnp.asarray(dr,dtype);cc=jnp.asarray(coeff,dtype)
    for name in ('SERIAL','OLD','WY'):
     got,gg=functions[(dtype_name,name,mode)](jnp.asarray(0,dtype),values,dd,cc)
     jax.block_until_ready((got,gg));g=float(gg)
     assert math.isfinite(g) and math.isfinite(float(got))
     with localcontext() as ctx:
      ctx.prec=a.precision+30;err=abs(Decimal.from_float(g)-gh)
     row['results'].append({'dtype':dtype_name,'algorithm':name,'gradient':g,'objective':float(got),
       'gradient_abs_error_vs_decimal':float(err),'gradient_sign_matches_oracle':bool((g>0)-(g<0)==(gh>0)-(gh<0)),
       'first_Adam_adaptive_update_lr1e-3':-1e-3*g/(abs(g)+1e-8),
       'adaptive_update_abs_error_vs_decimal_gradient':abs(-1e-3*g/(abs(g)+1e-8)-row['oracle_first_Adam_adaptive_update_lr1e-3']),
       'epsilon_sensitivity':{str(e):-1e-3*g/(abs(g)+e) for e in (1e-8,1e-7,1e-6)}})
   row['fp32_OLD_WY_opposite_sign']=bool(next(r['gradient'] for r in row['results'] if r['dtype']=='fp32' and r['algorithm']=='OLD')*next(r['gradient'] for r in row['results'] if r['dtype']=='fp32' and r['algorithm']=='WY')<0)
   report['cases'].append(row);save(a,report)
   print('HYPOTHESIS_CASE',seed,mode,'oracle',str(gh),'cancellation_ratio',condition,'OLD_WY_sign_flip',row['fp32_OLD_WY_opposite_sign'],flush=True)
 # Verify actual Optax behavior: epsilon does not generate an adaptive update from zero.
 p=jnp.asarray([-.02789476327598095],jnp.float32);zero=jnp.zeros_like(p)
 tx=optax.adamw(1e-3,weight_decay=0.);u,_=tx.update(zero,tx.init(p),p)
 assert float(u[0])==0.
 report['zero_gradient_control']={'adaptive_update_with_zero_gradient_zero_moments_no_weight_decay':float(u[0]),
   'epsilon_does_not_create_update':True,'with_weight_decay_only_expected':float(-1e-3*.01*p[0])}
 # Replay actual observed clipped gradients; this establishes amplification only, not their exact upstream error.
 report['actual_coordinate_replay_provenance']={'coordinate':'block_6/q_conv_w[236,2]',
  'seed':0,'previous_TPU_diagnostic_archive_sha256':'e3b05976c5f43ec09d59b940fbc6f5a1e603f1b8ae978c425f0f1e9121854d65',
  'initial_parameter':float(p[0]),'lr':.001,'weight_decay':.01,'epsilon':1e-8,
  'scope':'Previously observed clipped gradients transcribed into CPU replay, not a fresh full-LM execution.'}
 report['actual_coordinate_replay']=[]
 for name,g in [('NEW',1.3835218731555054e-8),('OLD',-9.705033074134847e-9)]:
  tx=optax.adamw(1e-3,weight_decay=.01);u,_=tx.update(jnp.asarray([g],jnp.float32),tx.init(p),p)
  report['actual_coordinate_replay'].append({'path':name,'observed_clipped_gradient':g,'Optax_first_update_CPU':float(u[0])})
 report['status']='completed'
 report['interpretation']={
  'conclusions_to_check':['Do FP64 scan/WY errors shrink relative to the independent oracle?',
   'Does cancellation stress increase sensitivity versus the natural objective?',
   'Do float32 gradient differences amplify under first-step AdamW near epsilon?'],
  'not_proven':['The actual full-LM coordinate has mathematical gradient exactly zero',
   'The original full-LM discrepancy is exclusively rounding and no implementation bug exists',
   'Four completed training runs prove no effect on model quality'],
  'scope':'Reduced stress case deliberately constructed for cancellation; not an estimate of its frequency in training.'}
 save(a,report);print('HYPOTHESIS_EXPERIMENT_COMPLETED',flush=True)

def save(a,report):
 temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2,allow_nan=False));temp.replace(a.output)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);p.add_argument('--length',type=int,default=256);p.add_argument('--dim',type=int,default=4)
 p.add_argument('--precision',type=int,default=80);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a)
