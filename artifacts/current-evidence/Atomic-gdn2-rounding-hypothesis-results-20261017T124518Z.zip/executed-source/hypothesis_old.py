import jax
import jax.numpy as jnp
PREC=jax.lax.Precision.HIGHEST
def old_impl(q,k,v,w,b,g,h0,scale):
 B,L,H,D=q.shape;C=128;N=L//C
 assert L%C==0
 alpha=jnp.exp(g.astype(q.dtype));ea=(b*k)*alpha;z=w*v
 def chunk(t):return jnp.moveaxis(t.reshape(B,N,C,H,D),1,0)
 def combine(s1,s2):
  m1,c1=s1;m2,c2=s2
  return jnp.matmul(m2,m1,precision=PREC),jnp.matmul(m2,c1,precision=PREC)+c2
 def step(carry,ci):
  cM,cS=carry;kc,eac,zc,ac,qc=ci
  M=jnp.eye(D,dtype=q.dtype)[None,None,None,:,:]*ac[...,None,:]-kc[..., :,None]*eac[...,None,:]
  U=kc[..., :,None]*zc[...,None,:]
  P,S=jax.lax.associative_scan(combine,(M,U),axis=1)
  gM=jnp.einsum('bchmn,bhnp->bchmp',P,cM,precision=PREC)
  gS=jnp.einsum('bchmn,bhnp->bchmp',P,cS,precision=PREC)+S
  out=scale*jnp.einsum('bchij,bchi->bchj',gS,qc,precision=PREC)
  return (gM[:,-1],gS[:,-1]),out
 eye=jnp.broadcast_to(jnp.eye(D,dtype=q.dtype),(B,H,D,D))
 (_,hf),out=jax.lax.scan(jax.checkpoint(step),(eye,h0),tuple(map(chunk,(k,ea,z,alpha,q))))
 return jnp.moveaxis(out,0,1).reshape(B,L,H,D),hf

def old_factory(scale):
 def impl(*args):return old_impl(*args,scale)
 @jax.custom_vjp
 def fn(*args):return impl(*args)
 def fwd(*args):
  out,pullback=jax.vjp(jax.checkpoint(impl),*args)
  return out,pullback
 def bwd(pullback,cotangent):return pullback(cotangent)
 fn.defvjp(fwd,bwd)
 return fn