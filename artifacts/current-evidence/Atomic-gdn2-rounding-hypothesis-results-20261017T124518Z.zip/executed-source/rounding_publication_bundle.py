"""Generate publication evidence, with explicit scope, from every completed case."""
import csv,hashlib,json,sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def main(root):
 report=json.loads((root/'report.json').read_text());out=root/'publication';out.mkdir(exist_ok=True)
 rows=[];oracles=[]
 for case in report['cases']:
  oracles.append({k:case[k] for k in ('seed','mode','oracle_gradient_decimal','oracle_precision_stability_abs','central_finite_difference_abs_error','derivative_cancellation_ratio','fp32_OLD_WY_opposite_sign')})
  for r in case['results']:
   rows.append(dict(seed=case['seed'],mode=case['mode'],dtype=r['dtype'],algorithm=r['algorithm'],gradient=r['gradient'],absolute_error=r['gradient_abs_error_vs_decimal'],sign_matches_oracle=r['gradient_sign_matches_oracle'],adaptive_update=r['first_Adam_adaptive_update_lr1e-3'],oracle_gradient=case['oracle_gradient_decimal'],oracle_adaptive_update=case['oracle_first_Adam_adaptive_update_lr1e-3'],input_sha256=case['input_sha256']))
 def csvfile(name,data):
  if data:
   with (out/name).open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 csvfile('all-gradients-and-updates.csv',rows);csvfile('oracle-checks.csv',oracles)
 csvfile('observed-coordinate-adam-replay.csv',report.get('actual_coordinate_replay',[]))
 csvfile('epsilon-sensitivity.csv',[dict(seed=c['seed'],mode=c['mode'],algorithm=r['algorithm'],dtype=r['dtype'],epsilon=e,adaptive_update=u) for c in report['cases'] for r in c['results'] for e,u in r['epsilon_sensitivity'].items()])
 improvements=[]
 for case in report['cases']:
  for name in ('SERIAL','OLD','WY'):
   pair={r['dtype']:r for r in case['results'] if r['algorithm']==name}
   e32=pair['fp32']['gradient_abs_error_vs_decimal'];e64=pair['fp64']['gradient_abs_error_vs_decimal']
   improvements.append(dict(seed=case['seed'],mode=case['mode'],algorithm=name,fp32_error=e32,fp64_error=e64,fp64_error_smaller=e64<e32,error_reduction_factor=e32/e64 if e64 else None))
 csvfile('precision-convergence.csv',improvements)
 stress=[c for c in report['cases'] if c['mode']=='cancellation_stress']
 natural=[c for c in report['cases'] if c['mode']=='natural']
 summary={'experiment_status':report['status'],'all_predeclared_cases_complete':len(report['cases'])==2*len(report['seeds_predeclared']),
 'controlled_stress_cases':len(stress),'controlled_stress_OLD_WY_fp32_opposite_signs':sum(c['fp32_OLD_WY_opposite_sign'] for c in stress),
 'natural_cases':len(natural),'natural_OLD_WY_fp32_opposite_signs':sum(c['fp32_OLD_WY_opposite_sign'] for c in natural),
 'precision_comparisons':len(improvements),'fp64_error_smaller_count':sum(r['fp64_error_smaller'] for r in improvements),
 'maximum_decimal_precision_check_absolute_error':max((c['oracle_precision_stability_abs'] for c in report['cases']),default=None),
 'maximum_finite_difference_absolute_error':max((c['central_finite_difference_abs_error'] for c in report['cases']),default=None),
 'scope':'Controlled reduced CPU experiment. No full-LM exact-gradient or quality claim; no speed claim.'}
 (out/'evidence-summary.json').write_text(json.dumps(summary,indent=2))
 (out/'execution-attestation.json').write_text(json.dumps({
  'author':'Akseleu Omirbay','kind':'Self-recorded computational evidence; not independent certification',
  'experiment_completed':report['status']=='completed' and summary['all_predeclared_cases_complete'],
  'environment':report['environment'],'stored_input_shape':report['shape'],'seeds':report['seeds_predeclared'],
  'decimal_precision_digits':[report['decimal_precision'],report['decimal_precision']+30],
  'report_sha256':hashlib.sha256((root/'report.json').read_bytes()).hexdigest(),
  'observed_coordinate_replay_provenance':report.get('actual_coordinate_replay_provenance'),
  'scope':summary['scope']},indent=2))
 tex=[r'\begin{tabular}{lllr rr}',r'\hline',r'Seed & Objective & Method & Precision & Gradient & Absolute error \\',r'\hline']
 for r in rows:
  mode='Natural' if r['mode']=='natural' else 'Stress'
  tex.append(f"{r['seed']} & {mode} & {r['algorithm']} & {r['dtype'].upper()} & {r['gradient']:.5e} & {r['absolute_error']:.3e}"+r' \\')
 tex.extend([r'\hline',r'\end{tabular}'])
 (out/'all-cases-table.tex').write_text('\n'.join(tex))
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
 if stress:
  fig,axes=plt.subplots(2,len(stress),figsize=(3.4*len(stress),5.5),squeeze=False)
  colors={'SERIAL':'#555555','OLD':'#2166ac','WY':'#b2182b'}
  for i,case in enumerate(stress):
   labels=[]
   for x,r in enumerate(case['results']):
    labels.append(r['algorithm']+'\n'+r['dtype'].upper())
    axes[0,i].scatter(x,max(r['gradient_abs_error_vs_decimal'],1e-300),color=colors[r['algorithm']],marker='o' if r['dtype']=='fp32' else 's',s=36)
    axes[1,i].scatter(x,r['first_Adam_adaptive_update_lr1e-3'],color=colors[r['algorithm']],marker='o' if r['dtype']=='fp32' else 's',s=36)
   axes[0,i].set_yscale('log');axes[0,i].set_title(f"Seed {case['seed']}")
   axes[1,i].axhline(case['oracle_first_Adam_adaptive_update_lr1e-3'],color='black',ls='--',lw=1,label='Decimal-gradient update')
   axes[1,i].axhline(0,color='#cccccc',lw=.7)
   for ax in axes[:,i]:ax.set_xticks(range(6),labels,fontsize=7);ax.grid(axis='y',alpha=.2)
   axes[1,i].ticklabel_format(axis='y',style='sci',scilimits=(0,0))
  axes[0,0].set_ylabel('Absolute gradient error vs Decimal');axes[1,0].set_ylabel('First adaptive Adam update')
  axes[1,-1].legend(fontsize=7,loc='best')
  fig.suptitle('Controlled cancellation stress test (reduced CPU recurrence)',fontsize=11)
  fig.tight_layout()
  for ext in ('pdf','svg','png'):fig.savefig(out/f'rounding-adam-stress.{ext}',dpi=220,bbox_inches='tight')
  plt.close(fig)
 caption='''Controlled cancellation stress test on a reduced GDN2 recurrence (CPU, B=1, L=256, H=1, D=4; seeds 0, 1, 2). SERIAL, OLD associative scan and pure-JAX chunked-WY use identical stored binary32 inputs and objective coefficients. FP64 promotes these values without changing them. Top: absolute scalar directional-gradient error against an independent sequential Decimal oracle (80 digits, checked at 110 digits and by central finite differences). Bottom: first bias-corrected adaptive Adam update, -0.001*g/(abs(g)+1e-8), with zero initial moments; dashed line uses the Decimal gradient. This panel excludes weight decay and global clipping; the separate observed-coordinate replay uses already-clipped gradients and Optax AdamW with weight decay. Stress coefficients intentionally create cancellation and do not estimate its prevalence in training. No Pallas kernel is executed here. Every predeclared seed is shown; ordinary quadratic-objective controls are included in the tables.'''
 (out/'figure-caption.txt').write_text(caption,encoding='utf-8')
 methods='''# Numerical sensitivity: methods and scope

This artifact tests a mechanism, not a predetermined conclusion. Stored float32 inputs are compared without changing their values. OLD and WY are derived transparently from archived benchmark sources; source derivations and hashes accompany the report. FP64 runs on CPU, not TPU. The independent Decimal oracle implements the literal sequential recurrence and forward tangent, without reusing scan/WY code. Decimal precision refinement and central finite differences check the oracle.

Both an ordinary quadratic objective and an intentionally constructed near-cancelling linear objective are reported for every predeclared seed. One stress coefficient is chosen using the oracle tangent and rounded to float32 before all algorithms run. This construction establishes possibility, not event frequency. Absolute errors are primary near zero; sign disagreement alone is not an accuracy metric.

The optimizer illustration uses zero initial moments. Its analytic update uses bias-corrected moments, excludes clipping and decay, and varies epsilon. A separate Optax replay starts from the previously observed clipped gradients; it tests amplification only. Epsilon does not generate an adaptive update from an exactly zero gradient with zero moments. Weight decay can still update parameters.

## Interpretation rule

If FP64 OLD/WY approach the independent oracle while FP32 differences persist, the data support finite-precision sensitivity on these inputs. If this does not happen, investigate algorithmic or implementation differences. Do not silently relabel a failed check as passed. Inspect evidence-summary.json, all cases and logs before writing a conclusion.

## Limits for publication

This reduced experiment does not establish the mathematically exact gradient of the original LM coordinate, exclude every Pallas implementation defect, establish long-run optimizer equivalence, or demonstrate unchanged validation quality. Previously completed training runs provide separate evidence of practical training behavior. Combine this experiment with the independent TPU NEW/JAX_REF comparison, but label their scopes separately. A controlled demonstration and an observed full-model discrepancy must not be described as the same experiment.

No independent statistical sampling claim is made from three predetermined seeds. Report all per-seed values rather than a significance test. These numbers are numerical diagnostics, not speedup measurements.

## Files

CSV files contain all cases, oracle checks, precision convergence and the observed-coordinate replay. The LaTeX table includes every algorithm, precision, objective and seed. Vector PDF/SVG and raster PNG show all stress cases. Original input arrays, exact executed sources, environment freeze, raw report and archive manifest support reproduction. Incomplete execution remains explicitly incomplete.
'''
 (out/'METHODS-AND-LIMITATIONS.md').write_text(methods,encoding='utf-8')
 (out/'artifact-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='artifact-hashes.json'},indent=2))
 print('PUBLICATION_EVIDENCE',json.dumps(summary),flush=True)

if __name__=='__main__':main(Path(sys.argv[1]))
