"""Measure all generations with non-blocking numerical diagnostics. One TPU executable at a time."""
import argparse,dataclasses,gc,hashlib,json,statistics,time,traceback
from pathlib import Path
import candidate_common as c
from candidate_e2e import initialize,make_functions
from corrected_original_lm import LMConfig
from isolated_e2e import functions,persist,fingerprint

def select(path):
 paths,cfg=c.paths(profile='no_damping')
 if path=='PALLAS_V1':
  import atomic_ops.gdn2_pipeline as pipeline
  from atomic_ops import KernelConfig
  import inspect
  assert Path(inspect.getsourcefile(pipeline.gdn2_pallas_forward_trainable)).resolve()==(c.ROOT/'atomic_ops/gdn2_pipeline.py').resolve()
  config=KernelConfig(bt=128,bc=64,mb=16,clip=1e4,wy_eps=0.)
  def fn(q,k,v,w,b,g,h0):return pipeline.gdn2_pallas_forward_trainable(q,k,v,w,b,g,1/128**.5,h0=h0,config=config)
  return fn,{'implementation':'atomic_ops.gdn2_pipeline.gdn2_pallas_forward_trainable','config':dataclasses.asdict(config)}
 return paths[path],{'implementation':{'OLD':'candidate_common.old_impl / affine associative_scan',
  'JAX_REF':'atomic_ops.reference.gdn2_chunked_wy_reference / pure JAX',
  'NEW':'atomic_gdn2.pipeline.make_blr_trainable / TPU Pallas'}[path],'config':cfg if path=='NEW' else {'wy_eps':0.,'chunk_length':128,'matmul_precision':'highest'}}

def save(a,r):
 temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(r,indent=2,allow_nan=False));temp.replace(a.output)

def fixed_timing(exe,args):
 warm=[]
 for _ in range(2):
  start=time.perf_counter();result=exe(*args);c.jax.block_until_ready(result);warm.append((time.perf_counter()-start)*1000)
  assert all(c.np.isfinite(c.np.asarray(x)).all() for x in c.jax.tree.leaves(result)),'Nonfinite warmup result'
  del result
 samples=[]
 for _ in range(4):
  start=time.perf_counter();result=exe(*args);c.jax.block_until_ready(result);samples.append((time.perf_counter()-start)*1000)
  # Host checks are outside the recorded interval; do not silently time nonfinite computations.
  assert all(c.np.isfinite(c.np.asarray(x)).all() for x in c.jax.tree.leaves(result)),'Nonfinite timed result'
  del result
 return c.summary(samples)|{'warmup_samples_ms':warm,'fixed_inputs_and_optimizer_state':True,
                            'full_tree_synchronized':True,'all_results_finite':True}

def run(a,r):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 fn,identity=select(a.path)
 r.update(path=a.path,kind=a.kind,identity=identity,environment=c.environment(),
          protocol='FIXED_STATE_ALL_PATHS_V1: 2 warmups, 4 timed calls, 3 rounds, 3 seeds; numerical deviations do not block timing',
          diagnostic_rel_l2=.005,relative_diagnostic_is_blocking=False,
          OLD_block_remat=(a.path=='OLD' and a.kind=='e2e'),
          scope='Raw latency; a numerical diagnostic FAIL is retained and must not be presented as an equivalence PASS')
 executable=None
 shape=tuple(map(int,a.shape.split(',')))
 for seed in (0,1,2):
  row={'seed':seed,'status':'initializing','rounds':[]};r['seeds'].append(row);save(a,r)
  if a.kind=='kernel':
   xs,digest=c.inputs(seed,shape);row['input_sha256']=digest;r['shape']=list(shape)
   # Each seed gets a separate closed-over h0. Remove previous executable/cache first.
   if executable is not None:del executable;c.jax.clear_caches();gc.collect()
   def objective(*args):return c.loss_for(fn)(*args,xs[-1])
   executable,seconds=c.compile_fn(c.jax.grad(objective,argnums=tuple(range(6))),xs[:-1])
   row['compile_seconds']=seconds
   observed=executable(*xs[:-1]);c.jax.block_until_ready(observed)
   row['snapshot']=persist(observed,a.intermediate/f'{a.label}-seed{seed}.npz')
   del observed
   args=xs[:-1]
  else:
   cfg=LMConfig();host=c.np.random.default_rng(seed).integers(0,256,(8,2048))
   tokens=c.jnp.asarray(host,c.jnp.int32);params=initialize(cfg,seed,tokens)
   assert sum(x.size for x in c.jax.tree.leaves(params))==34873952
   loss,step,tx=functions(cfg,fn,a.path=='OLD');state=tx.init(params)
   row.update(input_sha256=hashlib.sha256(host.tobytes()).hexdigest(),initial_parameters_sha256=fingerprint(params),initial_optimizer_sha256=fingerprint(state))
   initial=a.intermediate/f'initial-seed{seed}.npz';receipt=initial.with_suffix('.receipt.json')
   if not receipt.exists():
    data=persist(params,initial);data['fingerprint']=row['initial_parameters_sha256'];receipt.write_text(json.dumps(data,indent=2))
   assert json.loads(receipt.read_text())['fingerprint']==row['initial_parameters_sha256']
   r.update(parameters=34873952,batch=8,length=2048,model_config=dataclasses.asdict(cfg))
   if executable is None:
    executable,seconds=c.compile_fn(step,(params,state,tokens));r['compile_seconds']=seconds
    try:r['compiled_memory']=str(executable.memory_analysis())
    except Exception:r['compiled_memory']='unavailable'
   observed=executable(params,state,tokens);c.jax.block_until_ready(observed)
   row['snapshot']=persist(observed,a.intermediate/f'{a.label}-seed{seed}.npz')
   delta=c.jax.tree.map(lambda x,p:c.np.asarray(x)-c.np.asarray(p),observed[0],params)
   row['delta']=persist(delta,a.intermediate/f'{a.label}-delta-seed{seed}.npz')
   del observed,delta
   args=(params,state,tokens)
  row['status']='timing';save(a,r)
  for rnd in range(3):
   timing=fixed_timing(executable,args);row['rounds'].append({'round':rnd,'timing':timing});save(a,r)
  row['status']='completed';save(a,r);print('SPEED_SEED',a.label,seed,[x['timing']['median_ms'] for x in row['rounds']],flush=True)
  del args
  if a.kind=='kernel':del xs
  else:del params,state,tokens
  gc.collect()
 r['status']='completed'

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--path',choices=('OLD','JAX_REF','PALLAS_V1','NEW'),required=True)
 p.add_argument('--kind',choices=('kernel','e2e'),required=True);p.add_argument('--shape',default='4,2048,6,128')
 p.add_argument('--label',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--intermediate',type=Path,required=True);a=p.parse_args()
 r={'status':'running','seeds':[],'published':False}
 try:run(a,r)
 except Exception as e:r.update(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc());print('SPEED_ERROR',a.label,str(e),flush=True)
 finally:save(a,r)
 print('SPEED_FINAL',a.label,r['status'],flush=True)
 raise SystemExit(0 if r['status']=='completed' else 1)
