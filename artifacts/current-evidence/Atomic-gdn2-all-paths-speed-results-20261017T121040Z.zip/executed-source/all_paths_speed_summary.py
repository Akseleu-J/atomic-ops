"""Compare fixed-state latencies; retain every numerical deviation as a separate result."""
import argparse,csv,json,math,statistics
from pathlib import Path
import numpy as np

def compare(a,b):
 ma=json.loads(a.with_suffix('.meta.json').read_text());mb=json.loads(b.with_suffix('.meta.json').read_text())
 assert ma==mb,'Different tensor paths/shapes/dtypes'
 tensors=[]
 with np.load(a,allow_pickle=False) as aa,np.load(b,allow_pickle=False) as bb:
  for m in ma:
   av=aa[m['key']].astype(np.float64);bv=bb[m['key']].astype(np.float64)
   finite=bool(np.isfinite(av).all() and np.isfinite(bv).all())
   rel=float(np.linalg.norm((av-bv).ravel())/(np.linalg.norm(bv.ravel())+1e-12)) if finite else None
   tensors.append({'path':m['path'],'finite':finite,'rel_l2':rel,'passed':finite and rel<=.005,
                   'max_abs':float(np.max(np.abs(av-bv))) if finite else None})
 return {'passed':all(t['passed'] for t in tensors),'tensors':tensors}

def analyze(out,intermediate):
 paths=['OLD','JAX_REF','PALLAS_V1','NEW'];cases=['e2e']+[f'kernel-h{h}-l{l}' for h,l in [(6,2048),(2,2048),(2,4096),(4,2048),(4,4096),(6,4096)]]
 rows=[];sample_rows=[];diagnostics=[]
 for case in cases:
  records={}
  for path in paths:
   f=out/f'{case}-{path}.json'
   if not f.exists():continue
   r=json.loads(f.read_text())
   if r['status']!='completed':continue
   assert [s['seed'] for s in r['seeds']]==[0,1,2]
   for seed in r['seeds']:
    assert seed['status']=='completed' and len(seed['rounds'])==3
    for rnd in seed['rounds']:
     t=rnd['timing'];assert len(t['samples_ms'])==4 and len(t['warmup_samples_ms'])==2
     assert all(math.isfinite(x) and x>0 for x in t['samples_ms']+t['warmup_samples_ms'])
     assert math.isclose(statistics.median(t['samples_ms']),t['median_ms'],rel_tol=1e-12)
     for kind,key in [('warmup','warmup_samples_ms'),('timed','samples_ms')]:
      sample_rows.extend({'case':case,'path':path,'seed':seed['seed'],'round':rnd['round'],'kind':kind,'index':i,'ms':x} for i,x in enumerate(t[key]))
   records[path]=r
   seed_times=[statistics.median(x['timing']['median_ms'] for x in s['rounds']) for s in r['seeds']]
   rows.append({'case':case,'path':path,'latency_mean_ms':statistics.mean(seed_times),'latency_sample_SD_ms':statistics.stdev(seed_times),
                'OLD_over_path_mean':None,'OLD_over_path_SD':None,'JAX_REF_over_path_mean':None,'JAX_REF_over_path_SD':None})
  for row in [r for r in rows if r['case']==case]:
   target=records[row['path']]
   for baseline in ('OLD','JAX_REF'):
    if baseline not in records:continue
    reference=records[baseline];ratios=[]
    for seed in range(3):
     a=target['seeds'][seed];b=reference['seeds'][seed]
     assert a['input_sha256']==b['input_sha256']
     if case=='e2e':
      assert a['initial_parameters_sha256']==b['initial_parameters_sha256']
      assert a['initial_optimizer_sha256']==b['initial_optimizer_sha256']
     ratios.append(statistics.median(b['rounds'][i]['timing']['median_ms']/a['rounds'][i]['timing']['median_ms'] for i in range(3)))
     # Diag failures are retained and do not invalidate or block raw timing collection.
     prefix=f'{case}-{row["path"]}';refprefix=f'{case}-{baseline}'
     d=compare(intermediate/f'{prefix}-seed{seed}.npz',intermediate/f'{refprefix}-seed{seed}.npz')
     item={'case':case,'path':row['path'],'reference':baseline,'seed':seed,'snapshot':d}
     if case=='e2e':item['parameter_difference']=compare(intermediate/f'{prefix}-delta-seed{seed}.npz',intermediate/f'{refprefix}-delta-seed{seed}.npz')
     diagnostics.append(item)
    row[baseline+'_over_path_mean']=statistics.mean(ratios);row[baseline+'_over_path_SD']=statistics.stdev(ratios)
 for filename,data in [('summary.csv',rows),('all-timing-samples.csv',sample_rows)]:
  if data:
   with (out/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 report={'status':'analysis_completed','protocol':'FIXED_STATE_ALL_PATHS_V1','speed_is_equivalence_proof':False,
         'note':'Non-blocking numerical diagnostics; FAIL stays FAIL. Kernel snapshot is the timed six-input gradient; E2E snapshot is parameters/optimizer/loss, not standalone raw gradients.',
         'rows':rows,'diagnostics':diagnostics}
 (out/'analysis.json').write_text(json.dumps(report,indent=2,allow_nan=False))
 for r in rows:print('RESULT',r,flush=True)
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--intermediate',type=Path,required=True);a=p.parse_args();analyze(a.results,a.intermediate)
