"""Real full-LM coordinate: uninstrumented control and zero-probe VJP capture."""
import argparse,dataclasses,gc,hashlib,json,traceback
from pathlib import Path
import candidate_common as c
from candidate_e2e import adapter,initialize
from isolated_e2e import functions,fingerprint
from corrected_original_lm import LMConfig
import coordinate_probe_model as m
from flax import linen as nn
import optax

class ProbeRematLM(nn.Module):
 cfg:object
 kernel_fn:object
 @nn.compact
 def __call__(self,ids,probe):
  emb=nn.Embed(num_embeddings=self.cfg.vocab_size,features=self.cfg.d_model,name='embed');x=emb(ids)
  block=nn.remat(m.GDN2Block,prevent_cse=True)
  for i in range(self.cfg.n_layers):x=block(cfg=self.cfg,kernel_fn=self.kernel_fn,name=f'block_{i}')(x,probe)
  return emb.attend(nn.RMSNorm(epsilon=1e-6,name='final_norm')(x))

def probed_loss(cfg,fn,remat):
 model=(ProbeRematLM if remat else m.LM)(cfg=cfg,kernel_fn=adapter(fn,cfg.d_head))
 def loss(params,probe,ids):
  logits,aux=model.apply({'params':params},ids,probe,mutable=['intermediates'])
  value=optax.softmax_cross_entropy_with_integer_labels(logits[:,:-1],ids[:,1:]).mean()
  return value,aux['intermediates'][m.TARGET_BLOCK]['q_input'][0]
 return loss

def aligned_input(u,tap,width):
 offset=width-1-tap
 assert offset>=0
 if not offset:return u.copy()
 result=c.np.zeros_like(u);result[:,offset:]=u[:,:-offset];return result

def save(a,r):
 temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(r,indent=2,allow_nan=False));temp.replace(a.output)

def run(a,r):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 cfg=LMConfig();m.TARGET_BLOCK='block_6';m.TARGET_CHANNEL=236;tap=2
 paths,kc=c.paths(profile='no_damping');fn=paths[a.path];remat=a.path=='OLD'
 r.update(path=a.path,phase=a.phase,environment=c.environment(),config=dataclasses.asdict(cfg),
  target={'block':m.TARGET_BLOCK,'parameter':'q_conv_w','channel':m.TARGET_CHANNEL,'tap':tap},
  batch=8,length=2048,parameters=34873952,OLD_block_remat=remat,kernel_config=kc,
  scope='Diagnostic execution, not a speed benchmark. Instrumentation can change XLA arithmetic ordering.')
 if a.phase=='control':
  loss,_,_=functions(cfg,fn,remat);calc=c.jax.value_and_grad(loss)
 else:calc=c.jax.value_and_grad(probed_loss(cfg,fn,remat),argnums=(0,1),has_aux=True)
 exe=None
 for seed in (0,1,2):
  print('START',a.path,a.phase,seed,flush=True)
  host=c.np.random.default_rng(seed).integers(0,256,(8,2048));ids=c.jnp.asarray(host,c.jnp.int32)
  params=initialize(cfg,seed,ids);assert sum(x.size for x in c.jax.tree.leaves(params))==34873952
  row={'seed':seed,'input_sha256':hashlib.sha256(host.tobytes()).hexdigest(),'parameters_sha256':fingerprint(params)}
  probe=c.jnp.zeros((8,2048),c.jnp.float32)
  args=(params,ids) if a.phase=='control' else (params,probe,ids)
  if exe is None:
   print('COMPILE',a.path,a.phase,flush=True);exe,seconds=c.compile_fn(calc,args);r['compile_seconds']=seconds
   try:r['compiled_memory']=str(exe.memory_analysis())
   except Exception:r['compiled_memory']='unavailable'
  result=exe(*args);c.jax.block_until_ready(result)
  if a.phase=='control':value,grads=result
  else:(value,u),(grads,cot)=result
  assert all(c.np.isfinite(c.np.asarray(x)).all() for x in c.jax.tree.leaves(result))
  grad=float(grads[m.TARGET_BLOCK]['q_conv_w'][m.TARGET_CHANNEL,tap]);norm=float(optax.global_norm(grads))
  row.update(loss=float(value),raw_coordinate_gradient=grad,global_gradient_norm=norm,
   clipped_coordinate_gradient=grad/max(norm,1.),initial_parameter=float(params[m.TARGET_BLOCK]['q_conv_w'][m.TARGET_CHANNEL,tap]))
  if a.phase=='probe':
   uu=c.np.asarray(u);dd=c.np.asarray(cot);xx=aligned_input(uu,tap,cfg.d_conv)
   name=f'{a.path}-seed{seed}-coordinate.npz';p=a.output.parent/name
   c.np.savez_compressed(p,conv_input=uu,aligned_input=xx,cotangent=dd,
    q_conv_w_gradient=c.np.asarray(grads[m.TARGET_BLOCK]['q_conv_w']))
   row.update(arrays=name,arrays_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    sampled_terms=xx.size,probe_is_exactly_zero=True)
   del u,cot,uu,dd,xx
  r['seeds'].append(row);save(a,r);print('COMPLETE',a.path,a.phase,seed,grad,flush=True)
  del result,grads,params,ids,args,probe;gc.collect()
 r['status']='completed'

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--path',choices=['OLD','JAX_REF','NEW'],required=True)
 p.add_argument('--phase',choices=['control','probe'],required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 r={'status':'running','seeds':[]}
 try:run(a,r)
 except Exception as e:r.update(status='error',detail=repr(e),traceback=traceback.format_exc());print(r['traceback'],flush=True)
 finally:save(a,r)
 raise SystemExit(0 if r['status']=='completed' else 1)
