"""Exact rational contraction and cross-interventions on saved real-LM tensors."""
import csv,hashlib,itertools,json,math,sys
from decimal import Decimal,localcontext
from fractions import Fraction
from pathlib import Path
import numpy as np

def exact_dot(x,d):
 return sum((Fraction.from_float(float(a))*Fraction.from_float(float(b)) for a,b in zip(x.ravel(),d.ravel())),Fraction(0))
def dec(f):
 with localcontext() as ctx:
  ctx.prec=100;return str(Decimal(f.numerator)/Decimal(f.denominator))
def csvsave(path,rows):
 if rows:
  with path.open('w',newline='',encoding='utf-8') as f:
   w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main(out):
 paths=['OLD','JAX_REF','NEW'];records={};tensors={};issues=[]
 for path,phase in itertools.product(paths,['control','probe']):
  p=out/f'{path}-{phase}.json'
  if not p.exists():issues.append(f'Missing {p.name}');continue
  r=json.loads(p.read_text())
  if r['status']!='completed':issues.append(f'{p.name}: {r["status"]}');continue
  for row in r['seeds']:
   seed=row['seed'];records[path,phase,seed]=row
   if phase=='probe':
    p=out/row['arrays'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['arrays_sha256']
    with np.load(p,allow_pickle=False) as z:tensors[path,seed]={n:z[n].copy() for n in z.files}
 summaries=[];precision=[];cross=[];decomposition=[];instrumentation=[];epsrows=[]
 for seed in (0,1,2):
  available=[p for p in paths if (p,'probe',seed) in records]
  for path in available:
   row=records[path,'probe',seed];z=tensors[path,seed];x=z['aligned_input'];d=z['cotangent']
   assert x.dtype==np.float32 and d.dtype==np.float32 and np.isfinite(x).all() and np.isfinite(d).all()
   exact=exact_dot(x,d);sabs=exact_dot(abs(x),abs(d));ref=float(exact);g=row['raw_coordinate_gradient']
   cond=float(sabs/abs(exact)) if exact else None
   summaries.append(dict(seed=seed,path=path,TPU_gradient=g,frozen_local_exact_gradient=dec(exact),
    TPU_minus_local_exact=dec(Fraction.from_float(g)-exact),absolute_term_sum=float(sabs),cancellation_ratio=cond,
    positive_term_sum=dec((sabs+exact)/2),negative_term_sum=dec((exact-sabs)/2),
    TPU_vs_exact_opposite_sign=bool(g*ref<0),
    global_gradient_norm=row['global_gradient_norm'],exact_gradient_scope='Exact dot of captured rounded inputs/cotangent; not exact full-LM gradient'))
   products=(x*d).ravel();assert np.isfinite(products).all()
   left=np.float32(0)
   for term in products:left=np.float32(left+term)
   sorted_products=products[np.argsort(abs(products),kind='stable')]
   methods={'np_sum_FP32_products_FP32':float(np.sum(x*d,dtype=np.float32)),
    'left_fold_FP32_products_FP32':float(left),
    'small_to_large_FP32_products_FP32':float(np.sum(sorted_products,dtype=np.float32)),
    'large_to_small_FP32_products_FP32':float(np.sum(sorted_products[::-1],dtype=np.float32)),
    'FP32_products_sum_FP64':float(np.sum(x*d,dtype=np.float64)),
    'FP64_products_sum_FP64':float(np.sum(x.astype(np.float64)*d.astype(np.float64),dtype=np.float64)),
    'FP64_products_math_fsum':math.fsum(float(a)*float(b) for a,b in zip(x.ravel(),d.ravel()))}
   for method,value in methods.items():precision.append(dict(seed=seed,path=path,method=method,gradient=value,absolute_error_vs_exact=float(abs(Fraction.from_float(value)-exact))))
   control=records.get((path,'control',seed))
   if control:
    assert control['parameters_sha256']==row['parameters_sha256'] and control['input_sha256']==row['input_sha256']
    instrumentation.append(dict(seed=seed,path=path,unprobed_gradient=control['raw_coordinate_gradient'],probed_gradient=g,
     gradient_absolute_change=g-control['raw_coordinate_gradient'],unprobed_loss=control['loss'],probed_loss=row['loss'],
     norm_absolute_change=row['global_gradient_norm']-control['global_gradient_norm'],
     warning='Probe adds zero but changes compiled AD graph; inspect this change before applying explanation to original execution'))
   for eps in (1e-10,1e-9,1e-8,1e-7,1e-6):
    for source,value in [('TPU',g),('captured_local_exact',ref)]:
     gc=value/max(row['global_gradient_norm'],1.)
     epsrows.append(dict(seed=seed,path=path,source=source,epsilon=eps,clipped_gradient=gc,
      adaptive_update=-.001*gc/(abs(gc)+eps),weight_decay_update=-.001*.01*row['initial_parameter']))
  for a,b in itertools.product(available,repeat=2):
   ar,br=records[a,'probe',seed],records[b,'probe',seed]
   assert ar['parameters_sha256']==br['parameters_sha256'] and ar['input_sha256']==br['input_sha256']
   value=exact_dot(tensors[a,seed]['aligned_input'],tensors[b,seed]['cotangent'])
   cross.append(dict(seed=seed,input_path=a,cotangent_path=b,exact_contraction=dec(value)))
  for a,b in itertools.combinations(available,2):
   xa,xb=tensors[a,seed]['aligned_input'],tensors[b,seed]['aligned_input']
   da,db=tensors[a,seed]['cotangent'],tensors[b,seed]['cotangent']
   # Fraction arithmetic is exact even for the subtractions: never subtract in fp32 first.
   aa=exact_dot(xa,da);ba=exact_dot(xb,da);bb=exact_dot(xb,db)
   dx=aa-ba;dd=ba-bb;total=aa-bb;assert total==dx+dd
   decomposition.append(dict(seed=seed,path_a=a,path_b=b,exact_local_difference=dec(total),
    input_change_with_cotangent_a_fixed=dec(dx),cotangent_change_with_input_b_fixed=dec(dd),
    decomposition_exact=True,input_relative_l2=float(np.linalg.norm(xa.astype(float)-xb.astype(float))/(np.linalg.norm(xb.astype(float))+1e-300)),
    cotangent_relative_l2=float(np.linalg.norm(da.astype(float)-db.astype(float))/(np.linalg.norm(db.astype(float))+1e-300)),
    caveat='Frozen-tensor algebraic intervention; not a full nonlinear-model rerun or a causal proof about earlier kernels'))
 for name,rows in [('coordinate-summary',summaries),('local-precision',precision),('cross-contractions',cross),('difference-decomposition',decomposition),('instrumentation-control',instrumentation),('adam-epsilon',epsrows)]:csvsave(out/(name+'.csv'),rows)
 tex=[r'\begin{tabular}{llrrr}',r'\hline',r'Seed & Path & TPU gradient & Exact frozen contraction & Cancellation ratio \\',r'\hline']
 for row in summaries:
  condition='infinite' if row['cancellation_ratio'] is None else f"{row['cancellation_ratio']:.3e}"
  tex.append(f"{row['seed']} & {row['path'].replace('_',r'\_')} & {row['TPU_gradient']:.5e} & {float(row['frozen_local_exact_gradient']):.5e} & {condition}"+r' \\')
 tex.extend([r'\hline',r'\end{tabular}']);(out/'coordinate-table.tex').write_text('\n'.join(tex))
 report={'status':'completed' if not issues else 'incomplete','issues':issues,'complete_control_probe_seed_pairs':len(instrumentation),
  'expected_control_probe_seed_pairs':9,'coordinate_cases':summaries,'precision':precision,'decomposition':decomposition,'instrumentation':instrumentation,
  'interpretation':['TPU minus exact frozen dot localizes the final convolution reduction residual.',
   'Differences in captured cotangents precede that final reduction and require upstream explanation.',
   'High cancellation explains sensitivity, not which upstream implementation is accurate.',
   'Compare the unprobed control before attributing findings to the original reported gradient.',
   'No assertion that the true full-model gradient is zero, no universal no-bug or no-quality-impact claim.']}
 (out/'coordinate-analysis.json').write_text(json.dumps(report,indent=2,allow_nan=False))
 (out/'METHODS-AND-LIMITATIONS.md').write_text('''# Actual-coordinate numerical mechanism audit

The target is block_6/q_conv_w[236,2], seed 0 as originally observed, with seeds 1 and 2 as predeclared controls. The full original 34,873,952-parameter model, B8 L2048, is evaluated on TPU by OLD, JAX_REF and atomic_gdn2. OLD uses block remat. No timings are reported.

An additive zero probe at the selected convolution preactivation records its cotangent. The model also returns that convolution's input channel. For left padding K-1, tap j, the exact chain-rule contraction is sum(input[b,t+j-(K-1)] * cotangent[b,t]). Its captured-input value is computed with exact rational arithmetic: finite binary32 factors are exact rational numbers. Both factors already contain upstream rounding. This is not a high-precision oracle for the whole network.

The independent uninstrumented full-model gradient is rerun for each path and seed. A zero-valued probe changes the AD graph and can change XLA rounding. Differences must be disclosed; the instrumentation is not assumed numerically transparent. All full gradients are returned from executables; only compact coordinate evidence is archived.

Cross contractions hold either the captured input or cotangent fixed. An exact algebraic decomposition separates their contributions to the local gradient discrepancy. This locates where differences enter; it does not prove their exclusive upstream cause. FP32/FP64/fsum contractions quantify local rounding; cancellation ratios quantify conditioning of this sum. Epsilon sensitivity uses first-step bias-corrected Adam and separately reports weight decay. It does not establish equivalence of optimizer trajectories.

All arrays needed to reproduce the coordinate contractions are in the ZIP. Include every seed and any incomplete phase in reporting. Strong cancellation plus convergence of local FP64 to the exact dot supports a local rounding explanation; persistent differences between exact captured contractions locate upstream discrepancies and must not be silently dismissed. The preceding independent Decimal recurrence experiment is complementary evidence, not an oracle for the real full model.
''',encoding='utf-8')
 print('COORDINATE_ANALYSIS',report['status'],'pairs',len(instrumentation),flush=True)

if __name__=='__main__':main(Path(sys.argv[1]))
