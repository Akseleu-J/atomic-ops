"""Author's original eight-layer LM/AdamW, matched exact recurrence and full-step waits."""
import argparse,dataclasses,hashlib,json,statistics,time,traceback
import candidate_common as c
import optax
from corrected_original_lm import LMConfig,LM,SUPPLIED_MODEL_SHA256

def adapter(fn,head_dim):
 def run(q,k,v,w,b,g):
  h0=c.jnp.zeros((q.shape[0],q.shape[2],head_dim,head_dim),c.jnp.float32)
  return fn(q,k,v,w,b,g,h0)
 return run

def initialize(cfg,seed,tokens):
 def dummy(q,k,v,w,b,g):return q,c.jnp.zeros((q.shape[0],q.shape[2],q.shape[3],q.shape[3]),c.jnp.float32)
 model=LM(cfg=cfg,kernel_fn=dummy)
 params=model.init(c.jax.random.PRNGKey(seed),tokens)['params']
 return c.jax.tree.map(c.jax.device_put,params)

def make_functions(cfg,fn):
 model=LM(cfg=cfg,kernel_fn=adapter(fn,cfg.d_head))
 tx=optax.chain(optax.clip_by_global_norm(1.),optax.adamw(1e-3,weight_decay=.01))
 def loss(params,ids):
  logits=model.apply({'params':params},ids)
  return optax.softmax_cross_entropy_with_integer_labels(logits[:,:-1],ids[:,1:]).mean()
 def step(params,state,ids):
  val,grads=c.jax.value_and_grad(loss)(params,ids)
  updates,new_state=tx.update(grads,state,params)
  return optax.apply_updates(params,updates),new_state,val
 return loss,step,tx

def timed_step(exe,params,state,tokens,repeats,warmup=2):
 # Exactly the supplied evolving-state loop, with full result-tree synchronization fixed.
 p,s=params,state;warm=[]
 for _ in range(warmup):
  start=time.perf_counter();out=exe(p,s,tokens);c.jax.block_until_ready(out)
  warm.append((time.perf_counter()-start)*1000);p,s,_=out
 samples=[]
 for _ in range(repeats):
  start=time.perf_counter();out=exe(p,s,tokens);c.jax.block_until_ready(out)
  samples.append((time.perf_counter()-start)*1000);p,s,_=out
 finite=all(bool(c.np.isfinite(c.np.asarray(x)).all()) for x in c.jax.tree.leaves(out))
 assert finite,'Nonfinite result during evolving-state timing'
 return c.summary(samples)|dict(warmup_samples_ms=warm,repeats=repeats,warmup=warmup,
  input_positions_per_second=tokens.size/statistics.median(samples)*1000,
  predicted_tokens_per_second=tokens.shape[0]*(tokens.shape[1]-1)/statistics.median(samples)*1000,
  state_evolves=True,full_tree_synchronized=True,final_results_finite=finite,final_loss=float(out[2]))

def run(a):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 cfg=LMConfig();p,kernel_cfg=c.paths(cfg.d_head,a.profile)
 report=dict(status='running',kind='jax_reference_e2e',profile=a.profile,config=dataclasses.asdict(cfg),
  kernel_config=kernel_cfg,environment=c.environment(),supplied_model_sha256=SUPPLIED_MODEL_SHA256,
  batch=8,length=2048,microbatch=None,tolerance_rel_l2=c.TOL,
  optimizer='clip_by_global_norm(1.0), AdamW(lr=1e-3, weight_decay=.01), default optax moments/eps',
  protocol='Original order NEW then JAX_REF; two evolving-state warmups; NEW4/JAX_REF2 samples per round; median/population SD; full result synchronization',
  note='Same historical architecture; actual parameter count reported from model.init; counted from the initialized parameter tree. Synthetic uniform tokens, no corpus I/O.',seeds=[])
 functions={name:make_functions(cfg,p[name]) for name in ('NEW','JAX_REF')}
 exes={};gradfs={};shared_compile_s={}
 for seed in a.seeds:
  host=c.np.random.default_rng(seed).integers(0,cfg.vocab_size,size=(8,2048))
  tokens=c.jax.device_put(c.jnp.asarray(host,c.jnp.int32));params=initialize(cfg,seed,tokens)
  count=sum(x.size for x in c.jax.tree.leaves(params));report['params']=count
  assert count==34873952,('Unexpected historical architecture parameter count',count)
  states={};compile_s={}
  for name in ('NEW','JAX_REF'):
   loss,step,tx=functions[name];states[name]=tx.init(params)
   if name not in exes:
    print('CORRECTED_E2E_COMPILE',seed,name,'gradient',flush=True)
    gradfs[name],cg=c.compile_fn(c.jax.value_and_grad(loss),(params,tokens))
    print('CORRECTED_E2E_COMPILE',seed,name,'AdamW_step',flush=True)
    exes[name],cs=c.compile_fn(step,(params,states[name],tokens))
    compile_s[name]=dict(gradient_seconds=cg,step_seconds=cs)
    shared_compile_s[name]=compile_s[name]
  c.jax.block_until_ready((params,tokens,states))
  checks=dict(raw_parameter_gradients=c.check(gradfs['NEW'](params,tokens),gradfs['JAX_REF'](params,tokens)),
   full_optimizer_update=c.check(exes['NEW'](params,states['NEW'],tokens),exes['JAX_REF'](params,states['JAX_REF'],tokens)))
  np_,ns_,nl_=exes['NEW'](params,states['NEW'],tokens)
  rp_,rs_,rl_=exes['JAX_REF'](params,states['JAX_REF'],tokens)
  checks['parameter_updates']=c.check(c.jax.tree.map(lambda p,x:p-x,np_,params),c.jax.tree.map(lambda p,x:p-x,rp_,params))
  row=dict(seed=seed,input_sha256=hashlib.sha256(host.tobytes()).hexdigest(),checks=checks,compile_seconds=compile_s,executables_reused_across_seeds=True,
   passed=all(x['passed'] for x in checks.values()),rounds=[])
  if row['passed']:
   for rnd in range(a.rounds):
    times={name:timed_step(exes[name],params,states[name],tokens,4 if name=='NEW' else 2) for name in ('NEW','JAX_REF')}
    row['rounds'].append(dict(round=rnd,timing=times,speedup=times['JAX_REF']['median_ms']/times['NEW']['median_ms']))
   row['speedup']=statistics.median(r['speedup'] for r in row['rounds'])
  report['seeds'].append(row);c.save(report,a.output)
  print('CORRECTED_E2E_SEED',seed,row['passed'],row.get('speedup'),flush=True)
 report['status']='passed' if all(r['passed'] for r in report['seeds']) else 'gate_failed'
 report['shared_compile_seconds']=shared_compile_s
 if report['status']=='passed':
  ratios=[r['speedup'] for r in report['seeds']]
  report['speedup']=dict(per_seed=ratios,mean=statistics.mean(ratios),sample_sd=statistics.stdev(ratios) if len(ratios)>1 else 0.,
   historical_single_trial=report['seeds'][0]['rounds'][0]['speedup'],summary_method='median of round ratios per seed; mean and sample SD across seeds')
 return report

def cpu_check():
 c.jax.config.update('jax_default_matmul_precision','highest')
 assert c.jax.default_backend()=='cpu'
 # Actual full-model parameter count (dummy recurrence during init).
 cfg=LMConfig();tokens=c.jnp.zeros((1,128),c.jnp.int32);params=initialize(cfg,0,tokens)
 count=sum(x.size for x in c.jax.tree.leaves(params));assert count==34873952
 del params
 small=LMConfig(d_model=8,n_heads=2,d_head=4,n_layers=2,mlp_mult=2)
 p,_=c.paths(4,cpu=True);args,_=c.inputs(0,(1,256,2,4))
 oracle=c.jax.jit(c.jax.value_and_grad(c.loss_for(p['SERIAL']),argnums=tuple(range(7))))(*args)
 gate=c.check(c.jax.jit(c.jax.value_and_grad(c.loss_for(p['JAX_REF']),argnums=tuple(range(7))))(*args),oracle)
 assert gate['passed'],gate
 actual_dim,_=c.paths(128,cpu=True);dim_args,_=c.inputs(1,(1,128,1,128))
 dim_oracle=c.jax.jit(c.jax.value_and_grad(c.loss_for(actual_dim['SERIAL']),argnums=tuple(range(7))))(*dim_args)
 dim_gate=c.check(c.jax.jit(c.jax.value_and_grad(c.loss_for(actual_dim['JAX_REF']),argnums=tuple(range(7))))(*dim_args),dim_oracle)
 assert dim_gate['passed'],dim_gate
 ids=c.jnp.asarray(c.np.random.default_rng(0).integers(0,256,(1,128)),c.jnp.int32)
 params=initialize(small,0,ids);fns={k:make_functions(small,p[k]) for k in ('JAX_REF','SERIAL')}
 results={};grads={}
 for name,(loss,step,tx) in fns.items():
  grads[name]=c.jax.jit(c.jax.value_and_grad(loss))(params,ids)
  results[name]=c.jax.jit(step)(params,tx.init(params),ids)
 checks=dict(kernel_seven_gradients_two_chunks=gate,kernel_seven_gradients_D128=dim_gate,lm_raw_gradients=c.check(grads['JAX_REF'],grads['SERIAL']),
  lm_AdamW_update=c.check(results['JAX_REF'],results['SERIAL']))
 assert all(x['passed'] for x in checks.values()),checks
 print(json.dumps(dict(status='cpu_checks_passed',environment=c.environment(),full_historical_params=count,small_cfg=dataclasses.asdict(small),
  checks=checks,note='CPU mathematical checks only. No Pallas/TPU performance measured.'),indent=2),flush=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--profile',choices=('strict','production','no_damping'),default='production')
 p.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);p.add_argument('--rounds',type=int,default=3)
 p.add_argument('--output',default='corrected-original-e2e.json');p.add_argument('--cpu-check',action='store_true')
 a=p.parse_args();assert a.rounds>=1 and len(set(a.seeds))==len(a.seeds)
 if a.cpu_check:cpu_check();return 0
 try:r=run(a)
 except Exception as e:r=dict(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc(),environment=c.environment())
 c.save(r,a.output);print('FINAL_CORRECTED_E2E',r['status'],r.get('speedup'),flush=True)
 return 0 if r['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
