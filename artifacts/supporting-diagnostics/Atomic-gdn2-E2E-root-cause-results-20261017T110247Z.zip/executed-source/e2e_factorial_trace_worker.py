"""Instrumented numerical diagnosis, NOT the speed benchmark. One executable per child."""
import argparse,ast,dataclasses,gc,hashlib,json,re,traceback
from pathlib import Path
import candidate_common as c
from isolated_e2e import functions,persist,fingerprint
from candidate_e2e import initialize
from corrected_original_lm import LMConfig
import optax

VARIANTS={'OLD_remat':('OLD',True,'no_damping'),
 'OLD_plain':('OLD',False,'no_damping'),
 'JAX_REF_plain':('JAX_REF',False,'no_damping'),
 'JAX_REF_remat':('JAX_REF',True,'no_damping'),
 'NEW_bf16_plain':('NEW',False,'no_damping'),
 'NEW_bf16_remat':('NEW',True,'no_damping'),
 'NEW_highest_plain':('NEW',False,'strict')}

def save(a,r):
 temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(r,indent=2,allow_nan=False));temp.replace(a.output)

def first_step(params,grads):
 tx=optax.chain(optax.clip_by_global_norm(1.),optax.adamw(1e-3,weight_decay=.01))
 updates,state=tx.update(grads,tx.init(params),params)
 return {'direct_updates':updates,'parameters':optax.apply_updates(params,updates),'optimizer':state}

def load_dict(file,metadata,prefix=''):
 result={}
 with c.np.load(file,allow_pickle=False) as arrays:
  for m in metadata:
   if prefix and not m['path'].startswith(prefix):continue
   suffix=m['path'][len(prefix):]
   keys=re.findall(r"\['([^']+)'\]",suffix)
   assert keys and ''.join('['+repr(k)+']' for k in keys)==suffix,suffix
   cursor=result
   for key in keys[:-1]:cursor=cursor.setdefault(key,{})
   cursor[keys[-1]]=c.jnp.asarray(arrays[m['key']])
 return result

def run(a,r):
 c.jax.config.update('jax_default_matmul_precision','highest')
 if a.mode=='trace':c.require_tpu()
 else:assert c.jax.default_backend()=='cpu','Same-gradient optimizer control must be CPU-only'
 cfg=LMConfig();path,remat,profile=VARIANTS[a.variant]
 r.update(environment=c.environment(),variant=a.variant,path=path,block_remat=remat,
          model_config=dataclasses.asdict(cfg),parameters=34873952,batch=8,length=2048,
          active_implementation={'OLD':'candidate_common.old_impl / affine associative_scan',
           'JAX_REF':'atomic_ops.reference.gdn2_chunked_wy_reference / pure JAX',
           'NEW':'atomic_gdn2.pipeline.make_blr_trainable / Pallas'}[path],
          mode=a.mode,scope='Instrumented diagnosis only; no speed results',
          seeds_requested=a.seeds,tolerance_rel_l2=.005)
 exe=None
 if a.mode=='trace':
  paths,kc=c.paths(profile=profile);r['kernel_config']=kc
  loss,_,tx=functions(cfg,paths[path],remat)
  def trace(params,state,tokens):
   val,grads=c.jax.value_and_grad(loss)(params,tokens)
   updates,new_state=tx.update(grads,state,params)
   return {'loss':val,'gradients':grads,'gradient_global_norm':optax.global_norm(grads),
           'direct_updates':updates,'parameters':optax.apply_updates(params,updates),'optimizer':new_state}
 for seed in a.seeds:
  row={'seed':seed,'status':'initializing'};r['seeds'].append(row);save(a,r)
  if a.mode=='trace':
   host=c.np.random.default_rng(seed).integers(0,256,(8,2048))
   tokens=c.jnp.asarray(host,c.jnp.int32);params=initialize(cfg,seed,tokens)
   assert sum(x.size for x in c.jax.tree.leaves(params))==34873952
   digest=fingerprint(params);row.update(input_sha256=hashlib.sha256(host.tobytes()).hexdigest(),initial_parameters_sha256=digest)
   initial=a.intermediate/f'initial-seed{seed}.npz';receipt=initial.with_suffix('.receipt.json')
   if not receipt.exists():
    data=persist(params,initial);data['tree_fingerprint']=digest;receipt.write_text(json.dumps(data,indent=2))
   assert json.loads(receipt.read_text())['tree_fingerprint']==digest
   state=tx.init(params)
   if exe is None:
    print('COMPILE_TRACE',a.variant,flush=True)
    exe,seconds=c.compile_fn(trace,(params,state,tokens));r['compile_seconds']=seconds
    try:r['compiled_memory']=str(exe.memory_analysis())
    except Exception:r['compiled_memory']='unavailable'
   row['status']='executing';save(a,r)
   values=exe(params,state,tokens);c.jax.block_until_ready(values)
   del params,state,tokens
  else:
   initial=a.intermediate/f'initial-seed{seed}.npz'
   ir=json.loads(initial.with_suffix('.receipt.json').read_text())
   src=a.intermediate/f'{a.variant}-seed{seed}.npz'
   trace_report=json.loads((a.output.parent/(a.variant+'.json')).read_text())
   saved=next(s for s in trace_report['seeds'] if s['seed']==seed)
   with src.open('rb') as f:source_digest=hashlib.file_digest(f,'sha256').hexdigest()
   assert source_digest==saved['arrays']['sha256'],'Saved GPU trace checksum mismatch'
   with initial.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==ir['sha256']
   row['saved_GPU_trace_sha256']=source_digest
   params=load_dict(initial,ir['metadata'])
   grads=load_dict(src,json.loads(src.with_suffix('.meta.json').read_text()),"['gradients']")
   assert fingerprint(params)==ir['tree_fingerprint']
   row['initial_parameters_sha256']=ir['tree_fingerprint']
   if exe is None:exe,seconds=c.compile_fn(first_step,(params,grads));r['compile_seconds']=seconds
   values=exe(params,grads);c.jax.block_until_ready(values);del params,grads
  dest=a.intermediate/f'{a.variant}-{a.mode}-seed{seed}.npz'
  # Trace names are also made available under a stable path for the CPU optimizer control.
  if a.mode=='trace':dest=a.intermediate/f'{a.variant}-seed{seed}.npz'
  row['arrays']=persist(values,dest);row['status']='completed';save(a,r)
  print('TRACE_SEED_COMPLETE',a.variant,a.mode,seed,flush=True)
  del values;gc.collect()
 r['status']='completed'

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',choices=tuple(VARIANTS),required=True)
 p.add_argument('--mode',choices=('trace','cpu_optimizer'),default='trace')
 p.add_argument('--seeds',type=int,nargs='+',default=[0,1]);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--intermediate',type=Path,required=True);a=p.parse_args()
 r={'status':'running','seeds':[],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 try:run(a,r)
 except Exception as e:
  r.update(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc())
  print('TRACE_ERROR',a.variant,a.mode,str(e),flush=True)
 finally:save(a,r)
 print('TRACE_FINAL',a.variant,a.mode,r['status'],flush=True)
 raise SystemExit(0 if r['status']=='completed' else 1)
