"""Pure NumPy analysis of instrumented TPU traces; no JAX import or changed tolerances."""
import argparse,json,math
from pathlib import Path
import numpy as np

def metadata(file):return json.loads(file.with_suffix('.meta.json').read_text())
def relcheck(a,b):
 a=np.asarray(a,np.float64);b=np.asarray(b,np.float64)
 finite=bool(np.isfinite(a).all() and np.isfinite(b).all())
 if not finite:return {'finite':False,'passed':False,'rel_l2':None}
 diff=a-b;norm=float(np.linalg.norm(b.ravel()));error=float(np.linalg.norm(diff.ravel()))
 rel=error/(norm+1e-12)
 return {'finite':True,'passed':rel<=.005,'rel_l2':rel,'absolute_l2':error,
         'reference_norm':norm,'max_abs':float(np.max(np.abs(diff)))}

def compare(a,b,initial):
 ma={m['path']:m for m in metadata(a)};mb={m['path']:m for m in metadata(b)}
 mi={m['path']:m for m in metadata(initial)}
 families={k:[] for k in ('loss','gradients','direct_updates','parameters','optimizer','parameter_differences_fp32','parameter_differences_fp64')}
 details=[];parameter_map={}
 with np.load(a,allow_pickle=False) as aa,np.load(b,allow_pickle=False) as bb,np.load(initial,allow_pickle=False) as ii:
  for path,m in mb.items():
   if path not in ma:continue
   family=next((k for k in ('loss','gradients','direct_updates','parameters','optimizer') if path.startswith("['"+k+"']")),None)
   if family is None:continue
   av=aa[ma[path]['key']];bv=bb[m['key']]
   assert av.shape==bv.shape
   result={'path':path,**relcheck(av,bv)};families[family].append(result)
   if family!='parameters':continue
   suffix=path[len("['parameters']"):];iv=ii[mi[suffix]['key']]
   da32=av-iv;db32=bv-iv
   da64=av.astype(np.float64)-iv.astype(np.float64);db64=bv.astype(np.float64)-iv.astype(np.float64)
   r32={'path':suffix,**relcheck(da32,db32)};r64={'path':suffix,**relcheck(da64,db64)}
   families['parameter_differences_fp32'].append(r32);families['parameter_differences_fp64'].append(r64)
   update_path="['direct_updates']"+suffix
   ua=aa[ma[update_path]['key']];ub=bb[mb[update_path]['key']]
   if r32['passed'] and relcheck(ua,ub)['passed']:continue
   gp="['gradients']"+suffix
   if gp not in ma or gp not in mb:continue
   ga=aa[ma[gp]['key']];gb=bb[mb[gp]['key']]
   flat=np.argsort(np.abs(da64-db64).ravel())[-4:][::-1]
   detail={'path':suffix,'delta_fp32':r32,'delta_fp64':r64,'direct_update_check':relcheck(ua,ub),
           'raw_gradient_check':relcheck(ga,gb),'coordinates':[]}
   gna=float(aa[ma["['gradient_global_norm']"]['key']]);gnb=float(bb[mb["['gradient_global_norm']"]['key']])
   for index in flat:
    idx=np.unravel_index(int(index),av.shape)
    point={'index':list(map(int,idx)),'initial':float(iv[idx])}
    for name,params,g,updates,gn,delta in [('candidate',av,ga,ua,gna,da64),('reference',bv,gb,ub,gnb,db64)]:
     clipped=float(g[idx])*min(1.,1./gn)
     # Analytic first-step AdamW sensitivity only; no altered optimizer is executed on TPU.
     eps_sweep={str(e):-1e-3*(clipped/(abs(clipped)+e)+.01*float(iv[idx])) for e in (1e-8,1e-7,1e-6)}
     point[name]={'raw_gradient':float(g[idx]),'global_gradient_norm':gn,'analytic_clipped_gradient':clipped,
                  'direct_update':float(updates[idx]),'parameter_after':float(params[idx]),
                  'applied_difference_fp64':float(delta[idx]),'analytic_AdamW_epsilon_sensitivity':eps_sweep,
                  'parameter_ULP':float(abs(np.spacing(np.float32(params[idx]))))}
    point['gradient_sign_differs']=bool(np.signbit(ga[idx])!=np.signbit(gb[idx]))
    detail['coordinates'].append(point)
   details.append(detail)
 return {'families':{k:{'passed':all(t['passed'] for t in v),
                         'max_rel_l2':max((t['rel_l2'] for t in v if t['finite']),default=None),
                         'failed_tensors':[t for t in v if not t['passed']]} for k,v in families.items() if v},
         'failed_parameter_details':details}

def compare_same_gradient_gpu_cpu(gpu,cpu):
 mg={m['path']:m for m in metadata(gpu)};mc={m['path']:m for m in metadata(cpu)};checks=[]
 with np.load(gpu,allow_pickle=False) as gg,np.load(cpu,allow_pickle=False) as cc:
  for path,m in mc.items():
   result={'path':path,**relcheck(gg[mg[path]['key']],cc[m['key']])};checks.append(result)
 return {'scope':'Exactly the saved GPU gradient and initial parameters passed to Optax on CPU; platform/reduction rounding can differ.',
         'passed':all(t['passed'] for t in checks),'max_rel_l2':max((t['rel_l2'] for t in checks if t['finite']),default=None),
         'failed_tensors':[t for t in checks if not t['passed']]}

def analyze(results,intermediate,dest,seeds=(0,1)):
 comparisons=[('NEW_bf16_plain','OLD_remat'),('NEW_highest_plain','OLD_remat'),
  ('NEW_bf16_plain','JAX_REF_plain'),('NEW_highest_plain','JAX_REF_plain'),
  ('OLD_remat','JAX_REF_remat'),('JAX_REF_remat','JAX_REF_plain'),
  ('NEW_bf16_remat','NEW_bf16_plain'),('OLD_plain','OLD_remat')]
 report={'status':'diagnostic_completed','scope':'Instrumented numerical diagnosis, not speed qualification. Original threshold 0.005 retained.',
         'seeds':list(seeds),'comparisons':[],'same_gradient_optimizer_controls':[],
         'note':'Returning gradients/direct updates can change compiler optimization. Outcomes do not replace prior uninstrumented results. FP64 differences subtract stored float32 parameters in float64; this is not a float64 model.'}
 for a,b in comparisons:
  for seed in seeds:
   aa=intermediate/f'{a}-seed{seed}.npz';bb=intermediate/f'{b}-seed{seed}.npz';ii=intermediate/f'initial-seed{seed}.npz'
   if not all(p.exists() for p in (aa,bb,ii)):
    report['comparisons'].append({'candidate':a,'reference':b,'seed':seed,'status':'missing_trace'});continue
   ra=json.loads((results/(a+'.json')).read_text());rb=json.loads((results/(b+'.json')).read_text())
   sa=next(s for s in ra['seeds'] if s['seed']==seed);sb=next(s for s in rb['seeds'] if s['seed']==seed)
   assert sa['status']==sb['status']=='completed'
   assert sa['initial_parameters_sha256']==sb['initial_parameters_sha256']
   assert sa['input_sha256']==sb['input_sha256']
   report['comparisons'].append({'candidate':a,'reference':b,'seed':seed,'status':'compared',**compare(aa,bb,ii)})
 for meta in results.glob('*-cpu_optimizer.json'):
  r=json.loads(meta.read_text());variant=r.get('variant')
  for row in r.get('seeds',[]):
   if row.get('status')!='completed':continue
   seed=row['seed'];gpu=intermediate/f'{variant}-seed{seed}.npz';cpu=intermediate/row['arrays']['file']
   report['same_gradient_optimizer_controls'].append({'variant':variant,'seed':seed,**compare_same_gradient_gpu_cpu(gpu,cpu)})
 dest.write_text(json.dumps(report,indent=2,allow_nan=False))
 for row in report['comparisons']:
  if row['status']=='compared':print('COMPARISON',row['candidate'],'vs',row['reference'],'seed',row['seed'],{k:(v['passed'],v['max_rel_l2']) for k,v in row['families'].items()},flush=True)
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);p.add_argument('--intermediate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--seeds',type=int,nargs='+',default=[0,1]);a=p.parse_args()
 analyze(a.results,a.intermediate,a.output,a.seeds)
