"""Architecture copied from the author-supplied historical E2E snippet.
Only formatting changes from AST unparsing; no architectural substitutions.
"""
import dataclasses as dc,math
import jax
import jax.numpy as jnp
from flax import linen as nn
SUPPLIED_MODEL_SHA256='3c1e26ba720240b6fdde89b1bb44e9248f81a7890ec782a3b544aad185fd5992'

@dc.dataclass(frozen=True)
class LMConfig:
    vocab_size: int = 256
    d_model: int = 512
    n_heads: int = 6
    d_head: int = 128
    n_layers: int = 8
    mlp_mult: int = 2
    d_conv: int = 4
    g_max: float = 160.0 / 128
    decay_init: float = 0.05

    @property
    def proj_dim(self):
        return self.n_heads * self.d_head

class GDN2Block(nn.Module):
    cfg: LMConfig
    kernel_fn: object

    @nn.compact
    def __call__(self, x):
        cfg = self.cfg
        B, L, _ = x.shape
        H, D = (cfg.n_heads, cfg.d_head)
        proj_dim = H * D
        eps = 1e-06

        def sc(name, u):
            dim = u.shape[-1]
            w_ = self.param(f'{name}_conv_w', nn.initializers.normal(0.02), (dim, cfg.d_conv))
            bc = self.param(f'{name}_conv_b', nn.initializers.zeros, (dim,))
            rhs = w_.T[:, None, :].astype(u.dtype)
            return jax.lax.conv_general_dilated(u, rhs, window_strides=(1,), padding=[(cfg.d_conv - 1, 0)], feature_group_count=dim, dimension_numbers=('NHC', 'HIO', 'NHC')) + bc[None, None, :].astype(u.dtype)
        q = jax.nn.silu(sc('q', nn.Dense(proj_dim, use_bias=False, name='q_proj')(x))).reshape(B, L, H, D)
        k = jax.nn.silu(sc('k', nn.Dense(proj_dim, use_bias=False, name='k_proj')(x))).reshape(B, L, H, D)
        v = jax.nn.silu(sc('v', nn.Dense(proj_dim, use_bias=False, name='v_proj')(x))).reshape(B, L, H, D)
        v = jnp.clip(v, -50.0, 50.0)
        l2n = lambda t: t * jax.lax.rsqrt(jnp.sum(t * t, -1, keepdims=True) + eps)
        q = l2n(q)
        k = l2n(k)
        beta = jax.nn.sigmoid(nn.Dense(proj_dim, name='erase_gate')(x)).reshape(B, L, H, D)
        wg = jax.nn.sigmoid(nn.Dense(proj_dim, name='write_gate')(x)).reshape(B, L, H, D)
        bias0 = math.log(math.expm1(cfg.decay_init))
        da = self.param('decay_a', lambda k_, s: jnp.full(s, bias0, jnp.float32), (H,)).astype(jnp.float32)
        df = nn.Dense(H, use_bias=True, name='decay_proj')(x).astype(jnp.float32)
        ldh = -jnp.exp(jnp.clip(da, -20, 20))[None, None, :] * jax.nn.softplus(df)
        ld = jnp.broadcast_to(ldh[..., None], (B, L, H, D))
        ld = jnp.nan_to_num(ld, nan=0.0, posinf=0.0, neginf=-20.0)
        g = -jnp.minimum(jnp.abs(ld), cfg.g_max)
        o, _ = self.kernel_fn(q, k, v, wg, beta, g)
        o = o.reshape(B, L, proj_dim)
        og = nn.Dense(proj_dim, use_bias=False, name='out_gate')(x)
        o = nn.RMSNorm(epsilon=1e-06, name='mixer_out_norm')(o)
        x = x + nn.Dense(cfg.d_model, use_bias=False, name='out_proj')(o * jax.nn.silu(og))
        h2 = nn.RMSNorm(epsilon=1e-06, name='mlp_norm')(x)
        d = x.shape[-1]
        m = nn.Dense(d, use_bias=False, name='down_proj')(jax.nn.silu(nn.Dense(cfg.mlp_mult * d, use_bias=False, name='gate_proj')(h2)) * nn.Dense(cfg.mlp_mult * d, use_bias=False, name='up_proj')(h2))
        return x + m

class LM(nn.Module):
    cfg: LMConfig
    kernel_fn: object

    @nn.compact
    def __call__(self, ids):
        emb = nn.Embed(num_embeddings=self.cfg.vocab_size, features=self.cfg.d_model, name='embed')
        x = emb(ids)
        for i in range(self.cfg.n_layers):
            x = GDN2Block(cfg=self.cfg, kernel_fn=self.kernel_fn, name=f'block_{i}')(x)
        return emb.attend(nn.RMSNorm(epsilon=1e-06, name='final_norm')(x))
