"""Independent token-serial anchor: three seeds, two chunks, nonzero initial state."""
import sys
import candidate_common as c
c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
p,cfg=c.paths(profile='no_damping');rows=[]
for seed in (0,1,2):
 args,digest=c.inputs(seed,(1,256,1,128))
 oracle=c.jax.jit(p['SERIAL'])(*args)
 grad=c.jax.jit(c.jax.value_and_grad(c.loss_for(p['SERIAL']),argnums=tuple(range(7))))(*args)
 checks={}
 for name in ('OLD','JAX_REF','NEW'):
  checks[name]={'forward':c.check(c.jax.jit(p[name])(*args),oracle),
   'all_seven_gradients':c.check(c.jax.jit(c.jax.value_and_grad(c.loss_for(p[name]),argnums=tuple(range(7))))(*args),grad)}
 passed=all(g['passed'] for v in checks.values() for g in v.values())
 rows.append({'seed':seed,'input_sha256':digest,'checks':checks,'passed':passed})
 c.save({'status':'running','environment':c.environment(),'config':cfg,'seeds':rows},sys.argv[1])
 print('SERIAL_ANCHOR',seed,passed,flush=True)
report={'status':'passed' if all(r['passed'] for r in rows) else 'gate_failed',
 'environment':c.environment(),'config':cfg,'tolerance_rel_l2':c.TOL,'seeds':rows}
c.save(report,sys.argv[1]);raise SystemExit(0 if report['status']=='passed' else 1)
