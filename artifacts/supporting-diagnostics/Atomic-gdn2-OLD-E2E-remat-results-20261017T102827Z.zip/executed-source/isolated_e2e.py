"""One path/one executable per process. Full-size LM, host-persisted gates."""
import argparse,dataclasses,gc,hashlib,json,statistics,time,traceback
from pathlib import Path
import candidate_common as c
from candidate_e2e import initialize,timed_step,adapter
from corrected_original_lm import LMConfig,LM,GDN2Block
import optax
from flax import linen as nn

class RematLM(nn.Module):
 cfg: LMConfig
 kernel_fn: object
 @nn.compact
 def __call__(self,ids):
  emb=nn.Embed(num_embeddings=self.cfg.vocab_size,features=self.cfg.d_model,name='embed')
  x=emb(ids)
  # Same module names and shapes as the supplied LM. Recompute blocks during AD.
  Block=nn.remat(GDN2Block,prevent_cse=True)
  for i in range(self.cfg.n_layers):x=Block(cfg=self.cfg,kernel_fn=self.kernel_fn,name=f'block_{i}')(x)
  return emb.attend(nn.RMSNorm(epsilon=1e-6,name='final_norm')(x))

def functions(cfg,fn,remat):
 model=(RematLM if remat else LM)(cfg=cfg,kernel_fn=adapter(fn,cfg.d_head))
 tx=optax.chain(optax.clip_by_global_norm(1.),optax.adamw(1e-3,weight_decay=.01))
 def loss(params,ids):
  logits=model.apply({'params':params},ids)
  return optax.softmax_cross_entropy_with_integer_labels(logits[:,:-1],ids[:,1:]).mean()
 def step(params,state,ids):
  val,grads=c.jax.value_and_grad(loss)(params,ids)
  updates,state=tx.update(grads,state,params)
  return optax.apply_updates(params,updates),state,val
 return loss,step,tx

def persist(tree,dest):
 leaves=c.jax.tree_util.tree_flatten_with_path(tree)[0]
 arrays={f't{i:04d}':c.np.asarray(v) for i,(_,v) in enumerate(leaves)}
 metadata=[{'key':f't{i:04d}','path':c.jax.tree_util.keystr(p),'shape':list(v.shape),'dtype':str(v.dtype)} for i,(p,v) in enumerate(leaves)]
 c.np.savez(dest,**arrays)
 meta=dest.with_suffix('.meta.json');meta.write_text(json.dumps(metadata,indent=2))
 with dest.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(file=dest.name,bytes=dest.stat().st_size,sha256=digest,metadata=metadata)

def fingerprint(tree):
 h=hashlib.sha256()
 for path,v in c.jax.tree_util.tree_flatten_with_path(tree)[0]:
  a=c.np.asarray(v);h.update(c.jax.tree_util.keystr(path).encode());h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes())
 return h.hexdigest()

def run(a,report):
 c.jax.config.update('jax_default_matmul_precision','highest');c.require_tpu()
 cfg=LMConfig();paths,kc=c.paths(profile='no_damping');use_remat=a.path=='OLD'
 loss,step,tx=functions(cfg,paths[a.path],use_remat)
 report.update(config=dataclasses.asdict(cfg),kernel_config=kc,environment=c.environment(),
   batch=8,length=2048,parameters=34873952,OLD_block_remat=use_remat,
   existing_OLD_recurrence_remat=True,one_path_one_executable_per_process=True,
   source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')})
 exe=None
 for seed in (0,1,2):
  row={'seed':seed,'status':'initializing'};report['seeds'].append(row);save(a,report)
  host=c.np.random.default_rng(seed).integers(0,256,(8,2048))
  tokens=c.jnp.asarray(host,c.jnp.int32);params=initialize(cfg,seed,tokens)
  assert sum(x.size for x in c.jax.tree.leaves(params))==34873952
  row.update(input_sha256=hashlib.sha256(host.tobytes()).hexdigest(),initial_parameters_sha256=fingerprint(params))
  state=tx.init(params) if a.phase!='gradient' else None
  if exe is None:
   print('COMPILE',a.path,a.phase,'OLD_block_remat',use_remat,flush=True)
   fn=c.jax.value_and_grad(loss) if a.phase=='gradient' else step
   args=(params,tokens) if a.phase=='gradient' else (params,state,tokens)
   exe,seconds=c.compile_fn(fn,args);report['compile_s']=seconds
   del args  # Do not retain seed-0 params/state while processing later seeds.
   try:report['compiled_memory_analysis']=str(exe.memory_analysis())
   except Exception:report['compiled_memory_analysis']='unavailable'
  row['status']='executing';save(a,report)
  if a.phase=='gradient':
   result=exe(params,tokens);c.jax.block_until_ready(result)
   row['arrays']=persist(result,a.intermediate/f'{a.path}-gradient-seed{seed}.npz')
   del result
  elif a.phase=='step':
   result=exe(params,state,tokens);c.jax.block_until_ready(result)
   row['arrays']=persist(result,a.intermediate/f'{a.path}-step-seed{seed}.npz')
   # Compute float32 parameter differences on the host, preserving the same gate.
   delta=c.jax.tree.map(lambda x,p:c.np.asarray(x)-c.np.asarray(p),result[0],params)
   row['deltas']=persist(delta,a.intermediate/f'{a.path}-delta-seed{seed}.npz')
   del result,delta
  else:
   row['rounds']=[]
   for rnd in range(3):
    timing=timed_step(exe,params,state,tokens,4 if a.path=='NEW' else 2,warmup=2)
    row['rounds'].append({'round':rnd,'timing':timing});save(a,report)
  row['status']='completed';save(a,report);print('SEED_COMPLETE',a.path,a.phase,seed,flush=True)
  del params,tokens,state;gc.collect()
 report['status']='completed'

def save(a,report):
 temp=a.output.with_suffix('.tmp');temp.write_text(json.dumps(report,indent=2,allow_nan=False));temp.replace(a.output)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--path',choices=('NEW','OLD'),required=True);p.add_argument('--phase',choices=('gradient','step','timing'),required=True)
 p.add_argument('--output',type=Path,required=True);p.add_argument('--intermediate',type=Path,required=True);a=p.parse_args()
 a.intermediate.mkdir(exist_ok=True,parents=True)
 r={'status':'running','path':a.path,'phase':a.phase,'seeds':[],'published':False}
 save(a,r)
 try:run(a,r)
 except Exception as e:
  r.update(status='error',error=type(e).__name__,detail=str(e),traceback=traceback.format_exc())
  print('WORKER_ERROR',a.path,a.phase,type(e).__name__,str(e),flush=True)
 finally:save(a,r)
 print('WORKER_FINAL',a.path,a.phase,r['status'],flush=True)
 raise SystemExit(0 if r['status']=='completed' else 1)
