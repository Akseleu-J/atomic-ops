"""Shared corrected recurrence for the author's supplied historical benchmarks.

Retains the affine associative-scan baseline and original checkpoint/custom-VJP
structure. Removes matrix normalization and gradient clipping; honors scale/h0/hf.
"""
import dataclasses,hashlib,importlib.metadata,json,math,os,platform,statistics,sys,time
from pathlib import Path
import jax
import jax.numpy as jnp
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from atomic_gdn2 import make_cfg,make_blr_trainable
from atomic_ops.reference import gdn2_token_serial_reference, gdn2_chunked_wy_reference
from atomic_gdn2.reference import forward_ref
PREC=jax.lax.Precision.HIGHEST
TOL=.005
NAMES=('q','k','v','w','b','g','h0')

def old_impl(q,k,v,w,b,g,h0,scale):
 B,L,H,D=q.shape;C=128;N=L//C
 assert L%C==0
 alpha=jnp.exp(g.astype(jnp.float32));ea=(b*k)*alpha;z=w*v
 def chunk(t):return jnp.moveaxis(t.reshape(B,N,C,H,D),1,0)
 def combine(s1,s2):
  m1,c1=s1;m2,c2=s2
  return jnp.matmul(m2,m1,precision=PREC),jnp.matmul(m2,c1,precision=PREC)+c2
 def step(carry,ci):
  cM,cS=carry;kc,eac,zc,ac,qc=ci
  M=jnp.eye(D,dtype=q.dtype)[None,None,None,:,:]*ac[...,None,:]-kc[..., :,None]*eac[...,None,:]
  U=kc[..., :,None]*zc[...,None,:]
  P,S=jax.lax.associative_scan(combine,(M,U),axis=1)
  gM=jnp.einsum('bchmn,bhnp->bchmp',P,cM,precision=PREC)
  gS=jnp.einsum('bchmn,bhnp->bchmp',P,cS,precision=PREC)+S
  out=scale*jnp.einsum('bchij,bchi->bchj',gS,qc,precision=PREC)
  return (gM[:,-1],gS[:,-1]),out
 eye=jnp.broadcast_to(jnp.eye(D,dtype=q.dtype),(B,H,D,D))
 (_,hf),out=jax.lax.scan(jax.checkpoint(step),(eye,h0),tuple(map(chunk,(k,ea,z,alpha,q))))
 return jnp.moveaxis(out,0,1).reshape(B,L,H,D),hf

def old_factory(scale):
 def impl(*args):return old_impl(*args,scale)
 @jax.custom_vjp
 def fn(*args):return impl(*args)
 def fwd(*args):
  out,pullback=jax.vjp(jax.checkpoint(impl),*args)
  return out,pullback
 def bwd(pullback,cotangent):return pullback(cotangent)
 fn.defvjp(fwd,bwd)
 return fn

def paths(D=128,profile='strict',cpu=False):
 scale=1/math.sqrt(D);old=old_factory(scale)
 def serial(q,k,v,w,b,g,h0):return gdn2_token_serial_reference(q,k,v,g,b,w,scale,h0)
 def reference(q,k,v,w,b,g,h0):return gdn2_chunked_wy_reference(q,k,v,g,b,w,scale,128,h0,wy_eps=0.)
 result={'OLD':old,'SERIAL':serial,'JAX_REF':reference};cfg=None
 if not cpu:
  strict=profile=='strict'
  config=make_cfg(bt=128,bc=64,score_bs=128,bs2=64,mb=8,diag='btl',
   wy_eps=0. if strict or profile=='no_damping' else .001,dot_mode='highest',solve_dot_mode='highest' if strict else 'bf16x3',
   b3_dot_mode='highest' if strict else 'bf16x3',interpret=False)
  kernel=make_blr_trainable(config,scale)
  def new(q,k,v,w,b,g,h0):
   sw=lambda x:jnp.swapaxes(x,1,2)
   o,h=kernel(*(sw(x) for x in (q,k,v,w,b,g)),h0)
   return sw(o),h
  # Fail before timing if the candidate closure does not originate in atomic_gdn2.
  import inspect
  assert kernel.__module__=='atomic_gdn2.pipeline',kernel.__module__
  assert Path(inspect.getsourcefile(kernel)).resolve()==(ROOT/'atomic_gdn2/pipeline.py').resolve()
  assert config.interpret is False and config.wy_eps==0.0
  assert result['OLD'] is old and result['JAX_REF'] is reference and old is not reference
  result['NEW']=new;cfg=dataclasses.asdict(config)
 return result,cfg

def inputs(seed,shape=(4,2048,6,128)):
 B,L,H,D=shape
 keys=jax.random.split(jax.random.PRNGKey(seed),7)
 q=jax.random.normal(keys[0],shape)*.3;k=jax.random.normal(keys[1],shape)*.3
 q=q/(jnp.linalg.norm(q,axis=-1,keepdims=True)+1e-6)
 k=k/(jnp.linalg.norm(k,axis=-1,keepdims=True)+1e-6)
 v=jax.random.normal(keys[2],shape)*.3;g=-jnp.abs(jax.random.normal(keys[3],shape))*.05
 b=jax.random.uniform(keys[4],shape,minval=.2,maxval=1.)
 w=jax.random.uniform(keys[5],shape,minval=.2,maxval=1.)
 h0=jax.random.normal(keys[6],(B,H,D,D))*.1
 args=tuple(jax.device_put(t) for t in (q,k,v,w,b,g,h0));jax.block_until_ready(args)
 digest=hashlib.sha256(b''.join(np.asarray(x).tobytes() for x in args)).hexdigest()
 return args,digest

def loss_for(fn):
 def loss(*args):
  o,h=fn(*args);return jnp.sum(o.astype(jnp.float32)**2)+jnp.sum(h.astype(jnp.float32)**2)
 return loss

def check(got,ref,tolerance=TOL):
 assert jax.tree.structure(got)==jax.tree.structure(ref),'Different result trees'
 values=[]
 paths=[jax.tree_util.keystr(p) for p,_ in jax.tree_util.tree_flatten_with_path(ref)[0]]
 for path,a,b in zip(paths,jax.tree.leaves(got),jax.tree.leaves(ref)):
  a=np.asarray(a,np.float64);b=np.asarray(b,np.float64)
  assert a.shape==b.shape,(a.shape,b.shape)
  finite=bool(np.isfinite(a).all() and np.isfinite(b).all())
  rel=float(np.linalg.norm((a-b).reshape(-1))/(np.linalg.norm(b.reshape(-1))+1e-12)) if finite else None
  values.append(dict(path=path,shape=list(a.shape),finite=finite,rel_l2=rel,
   max_abs=float(np.max(np.abs(a-b))) if finite else None,reference_norm=float(np.linalg.norm(b.reshape(-1))) if finite else None))
 return dict(passed=bool(values) and all(v['finite'] and v['rel_l2']<=tolerance for v in values),tensors=values)

def compile_fn(fn,args):
 start=time.perf_counter();exe=jax.jit(fn).lower(*args).compile()
 return exe,time.perf_counter()-start

def timed(exe,args,repeats,warmup):
 warm=[]
 for _ in range(warmup):
  start=time.perf_counter();jax.block_until_ready(exe(*args));warm.append((time.perf_counter()-start)*1000)
 samples=[]
 for _ in range(repeats):
  start=time.perf_counter();jax.block_until_ready(exe(*args));samples.append((time.perf_counter()-start)*1000)
 return summary(samples)|dict(warmup_samples_ms=warm,repeats=repeats,warmup=warmup)

def summary(samples):
 return dict(samples_ms=samples,median_ms=statistics.median(samples),mean_ms=statistics.mean(samples),
  population_sd_ms=statistics.pstdev(samples),sample_sd_ms=statistics.stdev(samples) if len(samples)>1 else 0.)

def environment():
 versions={}
 for name in ('jax','jaxlib','libtpu','numpy','flax','optax'):
  try:versions[name]=importlib.metadata.version(name)
  except importlib.metadata.PackageNotFoundError:versions[name]=None
 return dict(python=sys.version,platform=platform.platform(),backend=jax.default_backend(),
  device_kinds=[x.device_kind for x in jax.devices()],devices=[str(x) for x in jax.devices()],
  implementation_identity=dict(candidate_module='atomic_gdn2.pipeline',candidate_source=str((ROOT/'atomic_gdn2/pipeline.py').resolve()),candidate_source_sha256=hashlib.sha256((ROOT/'atomic_gdn2/pipeline.py').read_bytes()).hexdigest(),baseline='candidate_common.old_impl: affine associative_scan',pure_JAX_reference='atomic_ops.reference.gdn2_chunked_wy_reference: validation only'),
  packages=versions,matmul_precision=str(jax.config.jax_default_matmul_precision),
  flags={n:os.environ.get(n) for n in ('XLA_FLAGS','JAX_PLATFORMS')})

def save(report,dest):
 report['executed_benchmark_sources']={f.name:hashlib.sha256(f.read_bytes()).hexdigest()
  for f in Path(__file__).parent.glob('*.py')}
 report['source_revision']='11616acd8a061768a38feb12c58e5e329952f5d5'
 report['kernel_source_sha256']={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'atomic_gdn2').rglob('*.py')}
 Path(dest).write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')

def require_tpu():
 assert jax.default_backend()=='tpu' and jax.local_device_count()==1,'Speed measurements require one real TPU'
